package ADT;
import java.util.Iterator;
import java.util.NoSuchElementException;

// Hashing uses a hashing function to map a key to an index.
// Hashing is a technique that retrieves the value using the index
// obtained from the key without performing a search.
public class SBTHashMap<K, V> implements SBTMapADT<K, V> {
	// the map:
	private int numberOfEntries;
	private static final int DEFAULT_CAPACITY = 5; 
	private static final int MAX_CAPACITY = 10000;
    
	// the hash table:
	private Entry<K, V>[] hashTable;	 // The hash table:
	private int tableSize; // Must be prime to improve distribution of hash indices, reduce collision risk
	private static final int MAX_SIZE = 2 * MAX_CAPACITY;
	private boolean integrityOK = false;
	private static final double MAX_LOAD_FACTOR = 0.5; // Fraction of hash table
	                                              
    protected final Entry<K, V> AVAILABLE = new Entry<>(null, null);
	
    public SBTHashMap() 
    {
    	this(DEFAULT_CAPACITY);
    }
    
    public SBTHashMap(int initialCapacity)
    {
    	initialCapacity = checkCapacity(initialCapacity);
    	numberOfEntries = 0;
         // Set up hash table:
        // Initial size of hash table is same as initialCapacity if it is prime;
       // otherwise increase it until it is prime size
       int tableSize = getNextPrime(initialCapacity);
        checkSize(tableSize); // Check that size is not too large

     // The cast is safe because the new array contains null entries
        @SuppressWarnings("unchecked")
        Entry<K, V>[] temp = (Entry<K, V>[])new Entry[tableSize];
        hashTable = temp;
        integrityOK = true;
    }
      // end constructor
    
 
    
    private class Entry<K, V> 
    {
    	private K key;
    	private V value;
    	

		private Entry(K searchKey, V dataValue)
    	{
	    	key = searchKey;
	    	value = dataValue;
    	}
    	
    	private K getKey()
    	{
    		return key;
    	}
    	
    	public V getValue() {
			return value;
		}

		public void setValue(V value) {
			this.value = value;
		}
    	
    }
    
    
    /**
     * Finds the smallest prime number that is greater than or equal to the given integer.
     * Based on the textbook description.
     */
    private int getNextPrime(int anInteger) {
        // if the anInteger is the smallest prime number, then directly increase by 1
        if (anInteger % 2 == 0) {
            anInteger++;
        }

        // find the first prime number among the parameter anInteger and subsequent odd integers.
        while (!isPrime(anInteger)) {
            anInteger = anInteger + 2; // Check the next odd number
        }

        return anInteger;
    }

    /**
     * Tests whether an integer is prime.
     * Based on the textbook logic.
     */
    private boolean isPrime(int anInteger) {
      
        if (anInteger <= 1) {
            return false;
        }
        

        if (anInteger == 2 || anInteger == 3) {
            return true;
        }

    
        if (anInteger % 2 == 0) {
            return false;
        }

        // "An odd integer 5 or greater is prime if it is not divisible by every odd integer up to its square root."
        // We start checking from 3, jumping by 2 (3, 5, 7...) to check only odd divisors.
        for (int i = 3; i * i <= anInteger; i += 2) {
            if (anInteger % i == 0) {
                return false; // It is divisible, so it's not prime
            }
        }

        return true;
    }
    
    private int checkCapacity(int capacity) {
        if (capacity < DEFAULT_CAPACITY) {
            capacity = DEFAULT_CAPACITY;
        } else if (capacity > MAX_CAPACITY) {
            throw new IllegalStateException("Attempt to create a dictionary " +
                                            "whose capacity is larger than " + MAX_CAPACITY);
        }
        return capacity;
    }
    
    private void checkSize(int size) {
        if (tableSize > MAX_SIZE) {
            throw new IllegalStateException("Dictionary has become too large.");
        }
    }

    private void checkIntegrity() {
        if (!integrityOK) {
            throw new SecurityException("HashedDictionary object is corrupt.");
        }
    }
    
    public V get(K key)
    {
    	checkIntegrity();
    	V result = null;
    	int index = getHashIndex(key);
    	if ((hashTable[index] != null) && (hashTable[index] != AVAILABLE))
    		result = hashTable[index].getValue();
    	return result;
    }
    
    /**
     *  this method illustrates the conflicts in hashmap. Since it is normal for many keys to be mapped into
     *  the same index, since key has lots of amount, but the hashtable has limited space. 
     *  the below use linear probing and open address to solve the conflict
     * @param key
     * @return
     */
    private int getHashIndex(K key) {
    	// get the beginning index to find the empty slot.
        int hashIndex = key.hashCode() % hashTable.length; // we cannot use it since many keys can have the same index after module.
        
        if (hashIndex < 0) {
            hashIndex = hashIndex + hashTable.length;
        }

        // Linear probing sequence
        while ((hashTable[hashIndex] != null) && !key.equals(hashTable[hashIndex].getKey())) {
            // Note: We do not stop at AVAILABLE because the key might have been pushed
            // further down the probe sequence before the deletion happened.
            hashIndex = (hashIndex + 1) % hashTable.length;// move the index to the nest one 
        }
        return hashIndex;
    }
    
    public V put(K key, V value) {
        checkIntegrity();
        if ((key == null) || (value == null))
            throw new IllegalArgumentException("Cannot add null key or value.");

        V oldValue = null;
        int index = getHashIndex(key);
        
        // index points to the key (if found) or the first available null (if not)
        // Note: Optimally we would reuse AVAILABLE entries here, but following 
        // strict linear probing for retrieval logic requires finding the key or null.
        
        // Check if key already exists
        if ((hashTable[index] != null) && (hashTable[index] != AVAILABLE)) {
            // Key found; replace value
            oldValue = hashTable[index].getValue();
            hashTable[index].setValue(value);
        } else {
            // Key not found; add new entry
            // In a robust implementation, we might search again for the first AVAILABLE slot 
            // to reuse memory, but standard linear probing inserts at the null.
            hashTable[index] = new Entry<>(key, value);
            numberOfEntries++;
        }

        // Ensure hash table is large enough for another addition
        if (isHashTableTooFull()) {
            enlargeHashTable();
        }

        return oldValue;
    }
    
    public V remove(K key) {
        checkIntegrity();
        V removedValue = null;
        int index = getHashIndex(key);

        if ((hashTable[index] != null) && (hashTable[index] != AVAILABLE)) {
            // Key found; flag entry as removed
            removedValue = hashTable[index].getValue();
            hashTable[index] = AVAILABLE;// available means labeling the slot where one previous entry is deleted
            numberOfEntries--;
        }
        // Else key not found; return null

        return removedValue;
    }
    
    public boolean containsKey(K key) {
        return get(key) != null;
    }

    public boolean isEmpty() {
        return numberOfEntries == 0;
    }

    public int getSize() {
        return numberOfEntries;
    }

    public void clear() {
        checkIntegrity();
        for (int index = 0; index < hashTable.length; index++) {
            hashTable[index] = null;
        }
        numberOfEntries = 0;
    }
    
    private void enlargeHashTable() {
        Entry<K, V>[] oldTable = hashTable;
        int oldSize = hashTable.length;
        int newSize = getNextPrime(oldSize + oldSize);
        checkSize(newSize);

        // The cast is safe because the new array contains null entries
        @SuppressWarnings("unchecked")
        Entry<K, V>[] temp = (Entry<K, V>[]) new Entry[newSize];
        hashTable = temp;
        tableSize = newSize; // Update tableSize
        numberOfEntries = 0; // Reset number of dictionary entries, since
                             // it will be incremented by add during rehash

        // Rehash dictionary entries from old array to the new and bigger array;
        // skip elements that contain null or AVAILABLE
        for (int index = 0; index < oldSize; index++) {
            if ((oldTable[index] != null) && (oldTable[index] != AVAILABLE)) {
                put(oldTable[index].getKey(), oldTable[index].getValue());
            }
        }
    }


    private boolean isHashTableTooFull() {
        return numberOfEntries > MAX_LOAD_FACTOR * hashTable.length;
    }
    
    public int size() {
        return numberOfEntries;
    }


    
    public SBTListADT<V> values() {

        SBTListADT<V> result = new SBTArrayList<>(numberOfEntries);

    
        Iterator<V> iterator = new ValueIterator(); 
        
        while (iterator.hasNext()) {
            result.add(iterator.next());
        }

        return result;
    }
    
    public Iterator<V> getValueIterator(){
    	return new ValueIterator();
    }
    
 // iterator is more memory efficient than List considering the size of data
    private class ValueIterator implements Iterator<V> {
        private int currentIndex;
        private int numberLeft;

        private ValueIterator() {
            currentIndex = 0;
            numberLeft = numberOfEntries;
        }

        public boolean hasNext() {
            return numberLeft > 0;
        }

        public V next() {
            V result = null;
            if (hasNext()) {
             
                while ((hashTable[currentIndex] == null) || 
                       (hashTable[currentIndex] == AVAILABLE)) {
                    currentIndex++;
                }
                
                result = hashTable[currentIndex].getValue(); //
                numberLeft--;
                currentIndex++;
            } else {
                throw new NoSuchElementException();
            }
            return result;
        }
    }
  }
   