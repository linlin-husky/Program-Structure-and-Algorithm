package ADT;

import java.util.Arrays;

/**
 * The below is a final class implementing the interface by adding the required data fields and completing all abstract methods;
 * final class cannot be subclassed 
 * unlike the normal array bag, it also need to consider the array resizing; 
 * @param <T> generic data type for flexible use. It should specify the concrete reference data type when creating an object. 
 */
public class SBTResizableBag<T> implements SBTBagADT<T> {
	private T[] bag; // Final was removed because array will be reassigned in the below doubleCapacity method
	private int numberOfEntries;// The number of actual items in the bag
	private static final int DEFAULT_CAPACITY = 5;// Uses static and final for the constant variable for default capacity initialized once for all.
	private static final int MAX_CAPACITY = 1000; // Uses static and final for the constant variable for the maximum capacity initialized once for all.
	private boolean integrityOK = false;// ensure the object is initialized fully by the constructor. 
	
/** the default no-arg constructor can be used to created an empty bag with default 5 capacity */ 
	public SBTResizableBag() {
		this(DEFAULT_CAPACITY);// use "this" to call the below alternative constructor 
	}
	
/** This is alternation one-arg constructor to create an empty bag with a certain capacity
 *   @param initialCapacity since this capacity can be doubled when adding the item, so initialCapacity is a better variable name than desiredCapacity. 
 */
	public SBTResizableBag(int initialCapacity) {
		{
			checkCapacity(initialCapacity);// fail safe code to ensure the object is initialized correctly within the reasonable capacity range

			@SuppressWarnings("unchecked") // used to suppress the warnings.
			T[] tempBag = (T[]) new Object[initialCapacity];// convert it to Object then cast Object to the generic since generic can not be directly created by new.  
			bag = tempBag; //we use the tempBag here to transfer the risk of cast to tempBag and keep bag safe. 
			numberOfEntries = 0;
			integrityOK = true;// ensure the object initialization exists
		}
	}
	

   /**This creates a bag which already have contents inside. by using the below Arrays.copyOf method, it can directly create a bag with contents, which 
      is more efficient than creating an empty bag and then adding items. 
      @param contents is generic array. */
	public SBTResizableBag(T[] contents) {
		checkCapacity(contents.length);
		bag = Arrays.copyOf(contents, contents.length);// create a new array with the length of the contents and copy the contents into this new array then assign it to the bag
		numberOfEntries = contents.length;
		integrityOK = true;// ensure the object is initialized fully by the constructor. 
	}
	
	/** Ensures there is indeed an object initialized */
	private void checkIntegrity() {
		 if (!integrityOK)
		 throw new SecurityException("ArrayBag object is corrupt.");
		 }
	
	/** Ensures an object is initialized with the acceptable capacity*/
	private void checkCapacity(int capacity) {
		if (capacity > MAX_CAPACITY)
			throw new IllegalStateException("Attempt to create a bag whose capacity exceeds " +
					"allowed maximum of " + MAX_CAPACITY);
	} 
	
    /**  Same method as isArrayFull() just set as public instead of private. 
         @return true if the items number is reaching the bag capacity. */  
	public boolean isFull() {
		return numberOfEntries == bag.length;
	}
    
	/* Returns true if there is no item in the bag*/
	public boolean isEmpty() {
		return numberOfEntries == 0;
	}
    
	/** Get the number of entries in the bag
	    @return the number of the items in the bag in integer data type.*/
	public int getCurrentSize() {
		return numberOfEntries;
	}
    
	/** Adds a certain new item into the bag
	    @param newEntry. the newEntry should theoretically not be null.
	    @return true if the item can be added successfully.*/
	public boolean add(T newEntry) {
		checkIntegrity();// ensure that there is indeed an object created correctly according to the constructor; 

		if (isFull()) {
			doubleCapacity();
		}

		bag[numberOfEntries] = newEntry;// add this newEntry to the last item in the array since bag does not care about the order.
		numberOfEntries++; // update the number of items and increase the value by 1

		return true;
	}
	
	/** This is to double the array length. The method is used in add(T newEntry) method.*/ 
	private void doubleCapacity() {
		int newLength = 2 * bag.length;
		
		if (newLength > MAX_CAPACITY) { 
		newLength = MAX_CAPACITY;// This is defensive coding to ensure we can still add items in case doubled capacity increases too fast to reach the maximum capacity.
	}
		
		checkCapacity(newLength); // Defensive code to ensure the capacity is maintained in a proper range.
		bag = Arrays.copyOf(bag, newLength); // Final must be removed in order to do array resizing, create a new array with doubled length and assign it to bag.
	}
    
	/** check if the certain item exists in the array bag
	  * @param Generic anEntry to be checked 
	  * @return true if this item is in the bag, if not, then false */  
	public boolean contains(T anEntry) {
		checkIntegrity();
		return getIndexOf(anEntry) > -1;
	}
	
	/** remove a certain item one time in the array bag
	  * @param Generic anEntry to be removed
	  * @return true if this item was successfully removed from the bag, if not, then false */  
	public boolean remove(T anEntry) {
		checkIntegrity();
		int index = getIndexOf(anEntry);
		T result = removeEntry(index);
		return anEntry.equals(result);
	}
	
	/** remove a certain item from the last item in the array bag. 
	  * @return Generic anEntry item removed*/  
	public T remove() {
		checkIntegrity();
		T result = removeEntry(numberOfEntries - 1);
		return result;
	}
    /**Search the index of a certain array
     * @param Generic anEntry 
     * @return if found the index, will return a positive integer. If not found, will return -1 */
	private int getIndexOf(T anEntry) {
		int where = numberOfEntries - 1; // search the array from the last item
		while ((where > -1) && !anEntry.equals(bag[where])) // decrease the largest index by one continually until it searched the exact same object
			where--;
		return where;
	}
   
	/** Removes and returns the entry at a given index within the array bag. If no such entry exists, returns null.
	 *  @param integer a certain index
	 *  @return generic data type, item to be removed at the certain given index
	 **/
	private T removeEntry(int givenIndex) {
		T result = null;
		if (!isEmpty() && (givenIndex >= 0)) {
			result = bag[givenIndex];// assign the removed item to result
			bag[givenIndex] = bag[numberOfEntries - 1];// assign the reference of the last element to where the removed item is
			bag[numberOfEntries - 1] = null;// disconnect the reference.
			numberOfEntries--;
		}
		return result;
	}
    
	/** Remove all items in the bag */ 
	public void clear() {
		while (!isEmpty())
			remove(); // so we still need to have the remove() method to always remove the last
						// element in an array.
	}
	
	   /** Retrieves all entries that are in this bag.
     * @return A newly allocated array of all the entries in the bag. 
     */
    public T[] toArray() {
        // the cast is safe because the new array contains null entries
        @SuppressWarnings("unchecked")
        T[] result = (T[]) new Object[numberOfEntries]; // unchecked cast
        for (int index = 0; index < numberOfEntries; index++) {
            result[index] = bag[index];
        } // end for
        return result;
    } // end toArray
    
	public int getFrequencyOf(T anEntry) {
	       checkIntegrity();
	       int counter = 0;
	       
	       if (anEntry == null ) { // exclude the special situation and prevent the NullPointerException
	        	return 0;// null means empty slot so there is no value to calculate the frequency
	        }
	        
		   for (int index = 0; index < numberOfEntries; index++) {
	           if (anEntry.equals(bag[index])) { // compare the object value between the anEntry and element in array.
	                counter++; // update the occurrence count
	           }
	        }
		   
	        return counter;        
	}
}
