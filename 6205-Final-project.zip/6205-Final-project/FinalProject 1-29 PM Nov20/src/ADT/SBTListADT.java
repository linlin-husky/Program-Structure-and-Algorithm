package ADT;

public interface SBTListADT<T> {
	/** Adds a new entry to the end of this list. */
    void add(T newEntry);

    /**
     * Adds a new entry at a specified position within this list.
     * @param newPosition position of the new entry (1..getLength()+1)
     * @throws IndexOutOfBoundsException if position is invalid
     */
    void add(int newPosition, T newEntry);

    /**
     * Removes the entry at a given position from this list.
     * @param givenPosition position of the entry to be removed (1..getLength())
     * @return the removed entry
     * @throws IndexOutOfBoundsException if position is invalid
     */
    T remove(int givenPosition);

    /** Removes all entries from this list. */
    void clear();

    /**
     * Replaces the entry at a given position in this list.
     * @param givenPosition position of the entry to be replaced
     * @param newEntry the new object that will replace the old one
     * @return the original entry that was replaced
     * @throws IndexOutOfBoundsException if position is invalid
     */
    T replace(int givenPosition, T newEntry);

    /**
     * Retrieves the entry at a given position in this list.
     * @param givenPosition position of the desired entry
     * @return the entry at givenPosition
     * @throws IndexOutOfBoundsException if position is invalid
     */
    T getEntry(int givenPosition);

    /**
     * Retrieves all entries that are in this list in the order in which they occur.
     * @return a newly allocated array of all the entries in the list
     */
    T[] toArray();

    /** Sees whether this list contains a given entry. */
    boolean contains(T anEntry);

    /** Gets the length (number of entries) of this list. */
    int getLength();

    /** Sees whether this list is empty. */
    boolean isEmpty();
}
