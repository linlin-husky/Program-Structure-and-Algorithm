package ADT;

public interface SBTComparator<T> {
	int compare(T o1, T o2);
}
