package ADT;

public class SBTArrayList<T> implements SBTListADT<T> {
	
    private T[] list;                 // Array of list entries; we ignore list[0]
    private int numberOfEntries;      

    private static final int DEFAULT_CAPACITY = 25;
    private static final int MAX_CAPACITY = 10000;

    public SBTArrayList() {
        this(DEFAULT_CAPACITY);
    }

    @SuppressWarnings("unchecked")
    public SBTArrayList(int initialCapacity) {
        if (initialCapacity < DEFAULT_CAPACITY) {
            initialCapacity = DEFAULT_CAPACITY;
        }
        checkCapacity(initialCapacity);
        
        list = (T[]) new Object[initialCapacity + 1];
        numberOfEntries = 0;
    }

 

    @Override
    public void add(T newEntry) {
        ensureCapacity();
        numberOfEntries++;
        list[numberOfEntries] = newEntry;
    }

    @Override
    public void add(int newPosition, T newEntry) {
        
        if ((newPosition >= 1) && (newPosition <= numberOfEntries + 1)) {
            ensureCapacity();
            if (newPosition <= numberOfEntries) {
                makeRoom(newPosition);
            }
            list[newPosition] = newEntry;
            numberOfEntries++;
        } else {
            throw new IndexOutOfBoundsException(
                    "add: illegal position " + newPosition);
        }
    }

    @Override
    public T remove(int givenPosition) {

        if ((givenPosition >= 1) && (givenPosition <= numberOfEntries)) {
            T result = list[givenPosition]; 
            if (givenPosition < numberOfEntries) {
                removeGap(givenPosition);
            }
     
            list[numberOfEntries] = null;
            numberOfEntries--;
            return result;
        } else {
            throw new IndexOutOfBoundsException(
                    "remove: illegal position " + givenPosition);
        }
    }

    @Override
    public void clear() {

        for (int i = 1; i <= numberOfEntries; i++) {
            list[i] = null;
        }
        numberOfEntries = 0;
    }

    @Override
    public T replace(int givenPosition, T newEntry) {
        if ((givenPosition >= 1) && (givenPosition <= numberOfEntries)) {
            T original = list[givenPosition];
            list[givenPosition] = newEntry;
            return original;
        } else {
            throw new IndexOutOfBoundsException(
                    "replace: illegal position " + givenPosition);
        }
    }

    @Override
    public T getEntry(int givenPosition) {
        if ((givenPosition >= 1) && (givenPosition <= numberOfEntries)) {
            return list[givenPosition];
        } else {
            throw new IndexOutOfBoundsException(
                    "getEntry: illegal position " + givenPosition);
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public T[] toArray() {
        T[] result = (T[]) new Object[numberOfEntries];
        for (int index = 0; index < numberOfEntries; index++) {
            // list 从 1 开始，result 从 0 开始
            result[index] = list[index + 1];
        }
        return result;
    }

    @Override
    public boolean contains(T anEntry) {
        boolean found = false;
        int index = 1;

        while (!found && (index <= numberOfEntries)) {
            if (anEntry == null) {
                if (list[index] == null) {
                    found = true;
                }
            } else if (anEntry.equals(list[index])) {
                found = true;
            }
            index++;
        }
        return found;
    }

    @Override
    public int getLength() {
        return numberOfEntries;
    }

    @Override
    public boolean isEmpty() {
        return numberOfEntries == 0;
    }
    
    @SuppressWarnings("unchecked")
    private void ensureCapacity() {
        int capacity = list.length - 1;  
        if (numberOfEntries >= capacity) {
            int newCapacity = 2 * capacity;
            checkCapacity(newCapacity);

            T[] newList = (T[]) new Object[newCapacity + 1];
          
            for (int i = 1; i <= numberOfEntries; i++) {
                newList[i] = list[i];
            }
            list = newList;
        }
    }

    private void makeRoom(int newPosition) {
      
        for (int index = numberOfEntries; index >= newPosition; index--) {
            list[index + 1] = list[index];
        }
    }

    private void removeGap(int givenPosition) {
        for (int index = givenPosition; index < numberOfEntries; index++) {
            list[index] = list[index + 1];
        }
    }

    /**
     * fail-safe code
     */
    private void checkCapacity(int capacity) {
        if (capacity > MAX_CAPACITY) {
            throw new IllegalStateException(
                    "Attempt to create a list whose capacity exceeds " +
                    "allowed maximum of " + MAX_CAPACITY);
        }
    }

}
