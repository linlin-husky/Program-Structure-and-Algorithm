package ADT;
/** SBT is the abbreviation of our group name: smart borrow tracker
 * use array to implement the ADT Deque (FIFO), a double-ended queue
 * Implements DequeueInterface used by the library reservation system.
 */
public interface SBTDequeADT<T> {
	/** Adds a new entry to the front/back of this deque. 
	 * @param newEntry An object to be added. */
	public void addToFront(T newEntry); 
	public void addToBack(T newEntry);
	

	/** Removes and returns the front/back entry of this deque.
	    @return  The object at the front/back of the deque.
	    @throws  EmptyQueueException if the deque is empty before
	operation. */
	public T removeFront();
	public T removeBack();
	
	/** Retrieves the front/back entry of this deque.
	    @return  The object at the front/back of the deque.
	    @throws  EmptyQueueException if the deque is empty. */
	public T getFront();
	public T getBack();
	public boolean isEmpty();
	public void clear();
	
	public int size();

}
