package ADT;

import java.util.Arrays;

/** use 'T extends Comparable' to ensure the elements in heap can use compareTO method
 * use 'T extends Comparable<? super T>' to ensure that a value of type T can be 
 * compared (using compareTo) with another value whose type is T or a supertype of T.
 */
public class SBTHeapPriorityQueue<T extends Comparable<? super T>> implements SBTPriorityQueueADT<T>  
{
	private T[] heap;  // use arrayList to implement heap
	private int size; // calculate the size of the heap array
	private static final int DEFAULT_CAPACITY = 25; // default capacity for heap array
	
	
    
	@SuppressWarnings("unchecked")
    public SBTHeapPriorityQueue() {
    	heap = (T[]) new Comparable[DEFAULT_CAPACITY]; 
    	// every array element stored in the heap array is of a type that implements Comparable
    	size = 0;
    }
    
	public boolean isFull() {
		return size == heap.length;
	}  
    /**
     * add the entry to the end of the head array, update size and percolate it up to ensure min-heap
     */
    public void add(T newEntry) {
    	// fail-safe code to prevent adding a null value
	  if (newEntry == null) {
          throw new IllegalArgumentException("Cannot add null");
	  } 
	  // if the heap is full, then double the capacity
	  if (isFull()) {
			doubleCapacity();
		}

        heap[size] = newEntry;// store the new entry as the last element in the head array
        percolateUp(size);
        size++;// 
	          // 
    }
    
    /**Percolate the node at the given index up the heap.
     * compare the childindex with its parent index, if the child is smaller
     * than the parent then swap it and raise it up to the position of parent
     * to ensure the smallest is always on the top of the heap
     * @param index index can not be minus 1.
     */
    private void percolateUp(int index) {
        int childIndex = index;
        while (childIndex > 0) {
            int parentIndex = (childIndex - 1) / 2;
            T child = heap[childIndex];
            T parent = heap[parentIndex];

            if (child.compareTo(parent) < 0) {
                swap(childIndex, parentIndex);
                childIndex = parentIndex;
            } else {
                break;
            }
        }
    }
    
    /**
     * 
     * @param index
     */
    private void percolateDown(int index) {
        int parentIndex = index;
     // compute the indices of the left and right children in the array
        while (true) {
            int leftChild = parentIndex * 2 + 1;
            int rightChild = parentIndex * 2 + 2;
            // assume the current parent is the smallest in this subtree
            int smallest = parentIndex;
            
         // if the left child exists and is smaller than the current smallest, update smallest
            if (leftChild < size && 
            		heap[leftChild].compareTo(heap[smallest]) < 0) {
                smallest = leftChild;
            }
            
          // if the right child exists and is smaller than the current smallest, update smallest
            if (rightChild < size && 
            		heap[rightChild].compareTo(heap[smallest]) < 0) {
                smallest = rightChild;
            }
            
         // if one of the children is smaller than the parent, swap and continue downward
            if (smallest != parentIndex) {
                swap(parentIndex, smallest);
                parentIndex = smallest;
            } else {
            	 // parent is already smaller than both children, min-heap is maintained. 
                break;
            }
        }
    }
    
    private void swap(int i, int j) {
        T tmp = heap[i];
        heap[i] = heap[j];
        heap[j] = tmp;
    }

    /**
     * Remove and return the element on the heap top, here is heap[0], which 
     * is always the smallest element in the heap.
     * After removing it, the last element in the heap is moved to the root,
     * and then percolated down to restore the min-heap property.
     * @return the smallest element in the heap, or null if the heap is empty
     */
    public T remove() {
        if (isEmpty()) {
            return null;
        }
        T min = heap[0];
        size--;
        
        if (size > 0) {
            heap[0] = heap[size];// move the last element to the top 
            heap[size] = null; // size automatically updated 
            percolateDown(0);
        } else {
        	heap[0] = null; // if the heap is empty return null
        }
        return min;
    }

	/** Retrieves the entry having the highest priority.
    @return   Either the object having the highest priority or, if
    priority queue is empty, null. */
    public T peek() {
        if (isEmpty()) {
            return null;
        }
        return heap[0];
    }

    public boolean isEmpty() {
        return size == 0;
    }
    
    public int size() {
        return size;
    }

    public void clear() {
    	 for (int i = 0; i < size; i++) {
             heap[i] = null;
         }
         size = 0;
    }
   
    private void doubleCapacity() {
        if (size >= heap.length) {
            int newCapacity = heap.length * 2;
            heap = Arrays.copyOf(heap, newCapacity);
        }
    }
      
}

