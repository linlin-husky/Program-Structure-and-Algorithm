// the below is our previous choices, left here for reference.
//package ADT;
//
///**
// * use array to implement the ADT Deque (FIFO), a double-ended queue
// * Implements DequeueInterface used by the library reservation system.
// */
//public class TeamLinkedQueue<T> implements TeamQueueADT<T> {
//	private Node<T> firstNode; // the first node in the queue
//	private Node<T> lastNode;// the last node in the queue
//	
//	 /**
//     * Adds a new entry to the back of this queue.
//     * 
//     * @param newEntry An object to be added.
//     */
//	public TeamLinkedQueue() {
//		firstNode = null;
//		lastNode = null;
//	}
//	
//	private class Node<T> {
//		private T data;
//		private Node<T> next;
//
//		private Node(T dataPortion) 
//		{
//			this(dataPortion, null);
//		}
//		
//		private Node(T dataPortion, Node nextNode) 
//		{
//			data = dataPortion;
//			next = nextNode;
//		}
//		
//		public void setData(T data) {
//			this.data = data;
//		}
//
//		private T getData()
//		{
//			return data;
//		}
//		
//		private Node<T> getNextNode() {
//			return next;
//		}
//
//		private void setNextNode(Node<T> nextNode) {
//			this.next = nextNode;
//		}
//		
//	}
//    
//	
//
//	 /**
//     * Adds a new entry to the back of this queue.
//     * @param newEntry An object to be added.
//     */
//	public void enqueue(T newEntry) {
//		Node<T> newNode = new Node<>(newEntry, null);
//		if (isEmpty()) {
//			firstNode = newNode;
//		
//		} else {
//		    lastNode.setNextNode(newNode);
//		    lastNode = newNode;
//		}
//	}
//	
//	public T getFront() 
//	{
//		if (isEmpty())
//			throw new EmptyQueueException();
//		else
//			return firstNode.getData();
//	}
//
//	 /**
//     * Removes and returns the entry at the front of this queue.
//     * @return The object at the front of the queue.
//     * @throws EmptyQueueException if the queue is empty before the operation.
//     */ 
//	public T dequeue() {
//		{
//			T front = getFront(); // Might throw EmptyQueueException // Assertion: firstNode != null firstNode.setData(null);
//			firstNode = firstNode.getNextNode();
//			if (firstNode == null)
//			lastNode = null; return front;
//			} // end dequeue
//	}
//	
//	/*
//	 * check if the queue is empty
//	 */
//	public boolean isEmpty()
//	{
//	return (firstNode == null) && (lastNode == null);
//	} // end isEmpty 
//	
//	public void clear()
//	{
//	firstNode = null; lastNode = null;
//	} // end clear
//
//
//	/**
//	 * removes and returns the entry at the front of this queue, 
//	 * but throws NoSuchElementException if the queue is empty 
//	 * prior to the operation.
//	 */
//	public T poll() {
//		if (isEmpty())
//			return null;
//		return dequeue();
//	}
//	
//	public int size() {
//	    int count = 0;
//	    Node<T> current = firstNode;
//	    while (current != null) {
//	        count++;
//	        current = current.getNextNode();
//	    }
//	    return count;
//	}
//
//}
//
//
//
//
