package ADT;
import java.util.Iterator;

/**
 * Map is a ADT similar to dictionary, which had key and value.
 * stores a collection of key/value pairs. It enables fast retrieval, deletion, 
 * and updating of the pair through the key. A map stores the values along with the keys.
 * The keys are like indexes. In List, the indexes are integers. 
 * In Map, the keys can be any objects. A map cannot contain duplicate keys. 
 * Each key maps to one value. A key and its corresponding value form an entry stored in a map
 * @param <K>
 * @param <V>
 */

public interface SBTMapADT<K,V> {
	
	
	  // Puts an entry into this map.
	   public V put(K key, V value);
	   
	  // Returns the value for the specified key in this map.
	   public  V get(K key);

	   // Removes the entries for the specified key.
	   public V remove(K key);
	   
	   //Returns true if this map contains an entry for the specified key. 
	   public boolean containsKey(K key);

	   
	   // Returns the number of entries in this map.
	   public int size();

	   // Returns true if this map contains no entries.
	   public boolean isEmpty();

	   //Removes all entries from this map. 
	   public void clear();
       
	   // iterator is flexible, memory-efficient 
	   public Iterator<V> getValueIterator();
	   
	   // in implementation, this use the iterator to get the list to reduce iteration 
	   // add this method here to ensure this method can be used by the outside class
	   // to further maintain program to an interface not an implementation.
	   public SBTListADT<V> values();

}
