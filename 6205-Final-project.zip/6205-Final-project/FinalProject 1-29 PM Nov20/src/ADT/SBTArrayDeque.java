package ADT;

/**
 * A Resizable Circular Array implementation of the Deque ADT.
 * Suitable for the Minuteman Library Reservation System.
 * * Comparison with Bag: Unlike Bag, this class maintains the order of elements (FIFO/LIFO)
 * and uses circular array logic to strictly achieve O(1) performance for front/back operations.
 * * @param <T> generic data type for flexible use.
 */
public class SBTArrayDeque<T> implements SBTDequeADT<T> {
	    
	    private T[] deque; // The array holding the data
	    private int frontIndex;// Index of the front entry
	    private int backIndex;  // Index of the back entry
	    private int numberOfEntries; // The number of actual items in the deque
	    
	    private static final int DEFAULT_CAPACITY = 5; // Default initial capacity
	    private static final int MAX_CAPACITY = 1000;  // Defensive limit
	    private boolean integrityOK = false; // ensure the object is initialized fully
	    
	    /** The default no-arg constructor creates an empty deque with default capacity */ 
	    public SBTArrayDeque() {
	        this(DEFAULT_CAPACITY);
	    }
	    
	    /** * Alternative one-arg constructor to create a deque with a certain capacity
	     * @param initialCapacity the desired initial size of the array
	     */
	    public SBTArrayDeque(int initialCapacity) {
	        checkCapacity(initialCapacity);
	        
	        // The cast is safe because the new array contains null entries
	        @SuppressWarnings("unchecked")
	        T[] tempDeque = (T[]) new Object[initialCapacity];
	        deque = tempDeque;  
	        frontIndex = 0;
	        // Initialize backIndex to capacity - 1. 
	        // This ensures that after the first addToBack, backIndex wraps around to 0.
	        backIndex = initialCapacity - 1; 
	        numberOfEntries = 0;
	        integrityOK = true;
	    }
	    
	    /** Ensures there is indeed an object initialized */
	    private void checkIntegrity() {
	        if (!integrityOK)
	            throw new SecurityException("LibraryArrayDeque object is corrupt.");
	    }

	    /** Ensures an object is initialized with the acceptable capacity */
	    private void checkCapacity(int capacity) {
	        if (capacity > MAX_CAPACITY)
	            throw new IllegalStateException("Attempt to create a deque whose capacity exceeds " +
	                    "allowed maximum of " + MAX_CAPACITY);
	    }
	    
	    /** Detects whether the array is full (circularly) */
	    private boolean isFull() {
	        return numberOfEntries == deque.length;
	    }
	    
	    @Override
	    public boolean isEmpty() {
	        return numberOfEntries == 0;
	    }
	    
	    @Override
	    public int size() {
	        return numberOfEntries;
	    }
	    
	    @Override
	    public void clear() {
	        checkIntegrity();
	        // While we could just set indices to 0, we must loop to nullify references for Garbage Collection
	        for (int i = 0; i < numberOfEntries; i++) {
	            int index = (frontIndex + i) % deque.length;
	            deque[index] = null;
	        }
	        numberOfEntries = 0;
	        frontIndex = 0;
	        backIndex = deque.length - 1;
	    }



	    @Override
	    public void addToFront(T newEntry) {
	        checkIntegrity();
	        
	        if (isFull()) {
	            doubleCapacity();
	        }
	        
	        // Math: Move Front Backward. 
	        // We add 'deque.length' before modulo to prevent negative results in Java.
	        frontIndex = (frontIndex - 1 + deque.length) % deque.length;
	        
	        deque[frontIndex] = newEntry;
	        numberOfEntries++;
	    }

	    @Override
	    public void addToBack(T newEntry) {
	        checkIntegrity();
	        
	        if (isFull()) {
	            doubleCapacity();
	        }
	        
	        // Math: Move Back Forward.
	        backIndex = (backIndex + 1) % deque.length;
	        
	        deque[backIndex] = newEntry;
	        numberOfEntries++;
	    }

	    @Override
	    public T removeFront() {
	        checkIntegrity();
	        
	        if (isEmpty()) {
	            throw new EmptyQueueException();
	        }
	        
	        T result = deque[frontIndex];
	        deque[frontIndex] = null; // Prevent memory leak (loitering object)
	        
	        // Move Front Forward
	        frontIndex = (frontIndex + 1) % deque.length;
	        numberOfEntries--;
	        
	        return result;
	    }

	    @Override
	    public T removeBack() {
	        checkIntegrity();
	        
	        if (isEmpty()) {
	            throw new EmptyQueueException();
	        }
	        
	        T result = deque[backIndex];
	        deque[backIndex] = null; // Prevent memory leak
	        
	        // Move Back Backward
	        backIndex = (backIndex - 1 + deque.length) % deque.length;
	        numberOfEntries--;
	        
	        return result;
	    }

	    @Override
	    public T getFront() {
	        checkIntegrity();
	        if (isEmpty()) {
	            throw new EmptyQueueException();
	        }
	        return deque[frontIndex];
	    }

	    @Override
	    public T getBack() {
	        checkIntegrity();
	        if (isEmpty()) {
	            throw new EmptyQueueException();
	        }
	        return deque[backIndex];
	    }



	    /** * Doubles the size of the array. 
	     * Unlike the Bag implementation, we CANNOT simply use Arrays.copyOf 
	     * because the data in a circular queue might be wrapped around the end of the array.
	     * We must "unroll" the loop into the new array.
	     */ 
	    private void doubleCapacity() {
	        int newLength = 2 * deque.length;
	        if (newLength > MAX_CAPACITY) {
	            // Defensive code: if doubling exceeds limit, try to cap at MAX (unless already there)
	            if (deque.length == MAX_CAPACITY) {
	                throw new IllegalStateException("Max capacity reached. Cannot add more items.");
	            }
	            newLength = MAX_CAPACITY;
	        }
	        
	        checkCapacity(newLength);
	        
	        @SuppressWarnings("unchecked")
	        T[] newDeque = (T[]) new Object[newLength];
	        
	        // Copying logic: Loop through the OLD logical order and place into NEW array starting at 0
	        for (int i = 0; i < numberOfEntries; i++) {
	            // Calculate where the data is in the old array
	            int oldIndex = (frontIndex + i) % deque.length;
	            // Place it linearly in the new array
	            newDeque[i] = deque[oldIndex];
	        }
	        
	        deque = newDeque;
	        
	        // Reset indices to standard positions
	        frontIndex = 0;
	        backIndex = numberOfEntries - 1;
	    }
	}


