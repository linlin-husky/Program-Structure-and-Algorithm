package ADT;

/**
 * Runtime exception thrown when attempting to access or remove
 * the front of an empty queue.
 */
public class EmptyQueueException extends RuntimeException {
    public EmptyQueueException() {
        super();
    }

    public EmptyQueueException(String message) {
        super(message);
    }
}
