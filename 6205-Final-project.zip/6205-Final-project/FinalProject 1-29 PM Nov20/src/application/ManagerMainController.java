package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ManagerMainController {

    @FXML
    private void handleManageRenewal(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(
                getClass().getResource("manager-view.fxml") 
        );
        Stage stage = (Stage) ((Node) event.getSource())
                .getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.setTitle("Malden Library - Manage Renewal");
        stage.show();
    }


    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        Main.setCurrentUser(null);

        Parent root = FXMLLoader.load(
                getClass().getResource("login-view.fxml"));
        Stage stage = (Stage) ((Node) event.getSource())
                .getScene().getWindow();
       
        Scene scene = new Scene(root);


        Main.applyAppStyles(scene);

        stage.setScene(scene);
        stage.setTitle("Malden Library Management System - Login");
        stage.show();
    }
}
