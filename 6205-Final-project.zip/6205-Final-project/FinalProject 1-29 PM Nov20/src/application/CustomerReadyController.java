package application;

import java.io.IOException;

import ADT.SBTArrayList;
import ADT.SBTListADT;
import Library.Book;
import Library.Branch;
import Library.LibrarySystem;
import Library.Loan;
import Users.Customer;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

public class CustomerReadyController {

    @FXML
    private TableView<Book> tblReady;

    @FXML
    private TableColumn<Book, String> colTitle;

    @FXML
    private TableColumn<Book, String> colBranch;

    @FXML
    private TableColumn<Book, String> colStatus;

    private LibrarySystem system;
    private Customer customer;

    private final ObservableList<Book> tableData =
            FXCollections.observableArrayList();

    public void setCustomer(Customer customer) {
        this.customer = customer;
        if (system != null) {
            loadReadyBooks();
        }
    }

    @FXML
    public void initialize() {
        system = Main.getSystem();
        if (Main.getCurrentUser() instanceof Customer && customer == null) {
            customer = (Customer) Main.getCurrentUser();
        }

        colTitle.setCellValueFactory(cd ->
                new SimpleStringProperty(cd.getValue().getTitle()));

        colBranch.setCellValueFactory(cd ->
                new SimpleStringProperty(
                        cd.getValue().getBranch() != null
                                ? cd.getValue().getBranch().getName()
                                : ""));

        colStatus.setCellValueFactory(cd ->
                new SimpleStringProperty(
                        cd.getValue().isAvailable()
                                ? "On Shelf"
                                : "borrowed"));

        tblReady.setItems(tableData);

        if (customer != null) {
            loadReadyBooks();
        }
    }

    private void loadReadyBooks() {
        tableData.clear();
        if (customer == null) return;

        // Build a set of books that have an active BORROWED loan for this customer
        java.util.Set<Book> assignedBooks = new java.util.HashSet<>();
        Loan[] customerLoans = system.getCustomerLoans(customer);
        if (customerLoans != null) {
            for (Loan loan : customerLoans) {
                if (loan != null && loan.getStatus() == Loan.Status.BORROWED && loan.getBook() != null) {
                    assignedBooks.add(loan.getBook());
                }
            }
        }

        ADT.SBTListADT<Book> result = new ADT.SBTArrayList<>();

        Object[] branchObjs = system.getAllBranches().toArray();
        for (Object objBranch : branchObjs) {
            Branch branch = (Branch) objBranch;

            Object[] bookObjs = branch.getAllBooks().toArray();
            for (Object objBook : bookObjs) {
                Book book = (Book) objBook;

                // A book is considered "ready" if either:
                // - it's available and this customer is on its waiting list, OR
                // - it has been assigned to this customer via an active BORROWED loan
                if ((book.isAvailable() && book.isOnWaitingList(customer)) || assignedBooks.contains(book)) {
                    result.add(book);
                }
            }
        }

        Object[] resultObjs = result.toArray();
        Book[] readyArray = new Book[resultObjs.length];
        for (int i = 0; i < resultObjs.length; i++) {
            readyArray[i] = (Book) resultObjs[i];
        }

        tableData.setAll(readyArray);
        tblReady.refresh();
    }

    @FXML
    private void handleBackToMain(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(
                getClass().getResource("customer-view.fxml"));
        Stage stage = (Stage) ((Node) event.getSource())
                .getScene().getWindow();
  
        
        Scene scene = new Scene(root);


        Main.applyAppStyles(scene);

        stage.setScene(scene);
        stage.setTitle("Malden Library - Customer");
        stage.show();
    }
}
