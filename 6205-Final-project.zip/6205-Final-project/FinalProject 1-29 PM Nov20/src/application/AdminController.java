package application;

import java.io.IOException;

import Library.LibrarySystem;
import Users.Customer;
import Users.Manager;
import Users.User;
import Users.UserRole;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AdminController {

    @FXML
    private ComboBox<String> cmbRole;

    @FXML
    private TextField txtName;

    @FXML
    private TextField txtEmail;

    @FXML
    private TextField txtUsername;

    @FXML
    private PasswordField txtPassword;

    @FXML
    private Label lblMessage;

    private LibrarySystem system;


    private static int customerCounter = 100;
    private static int managerCounter = 100;

    @FXML
    public void initialize() {
        system = Main.getSystem();

  
        cmbRole.setItems(FXCollections.observableArrayList(
                "Customer", "Manager"
        ));
    }

    @FXML
    private void handleCreateUser(ActionEvent event) {
        lblMessage.setText(""); 
        String roleText = cmbRole.getValue();
        String name = txtName.getText();
        String email = txtEmail.getText();
        String username = txtUsername.getText();
        String password = txtPassword.getText();


        if (roleText == null || roleText.isBlank()
                || name == null || name.isBlank()
                || email == null || email.isBlank()
                || username == null || username.isBlank()
                || password == null || password.isBlank()) {
            lblMessage.setStyle("-fx-text-fill: #cc0000;");
            lblMessage.setText("Please fill in all fields and select a role.");
            return;
        }

 
        String id;
        User newUser;

        if ("Customer".equals(roleText)) {
            id = "C" + (customerCounter++);
            newUser = new Customer(id, name, email, username, password);
        } else {
            id = "M" + (managerCounter++);
            newUser = new Manager(id, name, email, username, password);
        }

    
        system.registerUser(newUser);

        lblMessage.setStyle("-fx-text-fill: #008800;");
        lblMessage.setText("User created successfully: " + roleText + " - " + username);

 
        clearForm();
    }

    @FXML
    private void handleClear() {
        clearForm();
        lblMessage.setText("");
    }

    private void clearForm() {
        cmbRole.getSelectionModel().clearSelection();
        txtName.clear();
        txtEmail.clear();
        txtUsername.clear();
        txtPassword.clear();
    }

    @FXML
    private void handleBackToLogin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(
                getClass().getResource("login-view.fxml"));
        Stage stage = (Stage) ((Node) event.getSource())
                .getScene().getWindow();
        Scene scene = new Scene(root);
        
        Main.applyAppStyles(scene);

        stage.setScene(scene);
       
   
        stage.setTitle("Malden Library - Login");
        stage.show();
    }
}
