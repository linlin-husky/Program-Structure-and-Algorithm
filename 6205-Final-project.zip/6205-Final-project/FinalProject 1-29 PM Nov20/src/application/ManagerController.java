package application;
import java.io.IOException;
import java.time.LocalDate;

import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

import ADT.SBTArrayList;
import ADT.SBTListADT;

import Library.LibrarySystem;
import Library.AutoRenewResult;
import Library.Loan;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
public class ManagerController {
	@FXML
	private TableColumn<Loan, String> colBranch;
	
    @FXML
    private Button btnCheckDue;

    @FXML
    private TableView<Loan> tblLoans;

    @FXML
    private TableColumn<Loan, String> colBookTitle;

    @FXML
    private TableColumn<Loan, String> colBorrowerName;

    @FXML
    private TableColumn<Loan, String> colDueDate;

    @FXML
    private TableColumn<Loan, String> colStatus;
    private LibrarySystem system;
    
    @FXML
    private void handleManageRenewal(ActionEvent event) throws IOException {
        
        Parent root = FXMLLoader.load(
                getClass().getResource("manager-view.fxml")
        );
        Stage stage = (Stage) ((Node) event.getSource())
                .getScene().getWindow();
        Scene scene = new Scene(root);

        Main.applyAppStyles(scene);

        stage.setScene(scene);
        stage.show();
    }
//    @FXML
//    private void handleManageReservation(ActionEvent event) throws IOException {
//       
//        Parent root = FXMLLoader.load(
//                getClass().getResource("manager-reservation-view.fxml")
//        );
//        Stage stage = (Stage) ((Node) event.getSource())
//                .getScene().getWindow();
//        stage.setScene(new Scene(root));
//        stage.show();
//    }
   
    
    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        
        Main.setCurrentUser(null);

       
        Parent root = FXMLLoader.load(
                getClass().getResource("manager-main-view.fxml"));

        Stage stage = (Stage) ((Node) event.getSource())
                .getScene().getWindow();
   
     Scene scene = new Scene(root);
        
        Main.applyAppStyles(scene);

        stage.setScene(scene);
        stage.setTitle("Manager Work Area");
        stage.show();
    }

    @FXML
    public void initialize() {
        system = Main.getSystem();

        colBranch.setCellValueFactory(cellData ->
        new SimpleStringProperty(
                cellData.getValue()
                        .getBook()
                        .getBranch() != null
                    ? cellData.getValue().getBook().getBranch().getName()
                    : "" ));
        colBookTitle.setCellValueFactory(cellData ->
                new SimpleStringProperty(
                        cellData.getValue().getBook().getTitle()));

        colBorrowerName.setCellValueFactory(cellData ->
                new SimpleStringProperty(
                        cellData.getValue().getBorrower().getName()));

        colDueDate.setCellValueFactory(cellData ->
                new SimpleStringProperty(
                        String.valueOf(cellData.getValue().getDueDate())));

        colStatus.setCellValueFactory(cellData ->
                new SimpleStringProperty(
                        cellData.getValue().getStatus().name()));
        loadAllLoansToTable();
    }

    @FXML
    private void handleCheckDue() {
    	
    	  AutoRenewResult result = system.checkDueAndAutoRenew(LocalDate.now(), 7);

    	    loadAllLoansToTable();
    	    showAutoRenewAlerts(result);

    }
    
    private void showAutoRenewAlerts(AutoRenewResult result) {
       
        if (!result.hasAnyRenewed()) {
            Alert info = new Alert(Alert.AlertType.INFORMATION);
            info.setTitle("Auto Renewal");
            info.setHeaderText(null);
            info.setContentText("There are no loans that can be renewed at this time.");
            info.showAndWait();
        }

        if (!result.getOverLimitLoans().isEmpty()) {

            StringBuilder sb = new StringBuilder();
            sb.append("These loans have already been renewed more than 2 times and cannot be renewed again:\n\n");

            Loan[] overLimitArray = result.getOverLimitLoans().toArray();
            for (Loan loan : overLimitArray) {
                sb.append("- Book: ")
                  .append(loan.getBook().getTitle())
                  .append(" (Branch: ")
                  .append(loan.getBook().getBranch() != null
                          ? loan.getBook().getBranch().getName()
                          : "N/A")
                  .append(")\n  Borrower: ")
                  .append(loan.getBorrower().getName())
                  .append("\n\n");
            }

            Alert overLimitAlert = new Alert(Alert.AlertType.WARNING);
            overLimitAlert.setTitle("Renewal Limit Reached");
            overLimitAlert.setHeaderText("Some loans have reached the maximum number of renewals.");
            overLimitAlert.setContentText(sb.toString());
            overLimitAlert.showAndWait();
        }
    }

    private void loadAllLoansToTable() {

        SBTListADT<Loan> loans = system.getAllLoans();

        Object[] loanObjs = loans.toArray();
        Loan[] loanArray = new Loan[loanObjs.length];
        for (int i = 0; i < loanObjs.length; i++) {
            loanArray[i] = (Loan) loanObjs[i];
        }

        tblLoans.setItems(FXCollections.observableArrayList(loanArray));
        tblLoans.refresh();
    }
    
    

}
