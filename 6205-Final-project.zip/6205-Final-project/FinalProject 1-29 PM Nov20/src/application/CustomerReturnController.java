package application;
import java.io.IOException;
import java.time.format.DateTimeFormatter;

import ADT.SBTArrayList;
import ADT.SBTListADT;
import Library.Book;
import Library.Branch;
import Library.LibrarySystem;
import Library.Loan;
import Users.Customer;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

public class CustomerReturnController {
	
	   @FXML
	    private TableView<Loan> tblLoans;

	    @FXML
	    private TableColumn<Loan, String> colTitle;

	    @FXML
	    private TableColumn<Loan, String> colBranch;

	    @FXML
	    private TableColumn<Loan, String> colDueDate;

	    @FXML
	    private TableColumn<Loan, String> colRenewCount;

	    @FXML
	    private TableColumn<Loan, String> colStatus;

	    private LibrarySystem system;
	    private Customer customer;

	    private final ObservableList<Loan> tableData =
	            FXCollections.observableArrayList();

	    private final DateTimeFormatter DATE_FMT =
	            DateTimeFormatter.ofPattern("yyyy-MM-dd");

	  
	    public void setCustomer(Customer customer) {
	        this.customer = customer;
	   
	        if (system != null) {
	            loadCurrentLoans();
	        }
	    }

	    @FXML
	    public void initialize() {
	        system = Main.getSystem();
	        if (Main.getCurrentUser() instanceof Customer && customer == null) {
	            customer = (Customer) Main.getCurrentUser();
	        }

	 
	        colTitle.setCellValueFactory(cd ->
	                new SimpleStringProperty(
	                        cd.getValue().getBook().getTitle()));

	        colBranch.setCellValueFactory(cd ->
	                new SimpleStringProperty(
	                        cd.getValue().getBook().getBranch() != null
	                                ? cd.getValue().getBook().getBranch().getName()
	                                : ""));

	        colDueDate.setCellValueFactory(cd ->
	                new SimpleStringProperty(
	                        cd.getValue().getDueDate() != null
	                                ? cd.getValue().getDueDate().format(DATE_FMT)
	                                : ""));

	        colRenewCount.setCellValueFactory(cd ->
	                new SimpleStringProperty(
	                        String.valueOf(cd.getValue().getRenewCount())));

	        colStatus.setCellValueFactory(cd ->
	                new SimpleStringProperty(
	                        cd.getValue().getStatus().name()));

	        tblLoans.setItems(tableData);

	      
	        if (customer != null) {
	            loadCurrentLoans();
	        }
	    }
      
	    private void loadCurrentLoans() {
	        tableData.clear();
	        if (customer == null) return;

	      
	        Loan[] loans = system.getCustomerLoans(customer);

	        // tableData.setAll() can only take array as the parameter.
	        tableData.setAll(loans);
	        tblLoans.refresh();
	    }

	    @FXML
	    private void handleReturnSelected() {
	        Loan selected = tblLoans.getSelectionModel().getSelectedItem();
	        if (selected == null) {
	            showAlert(Alert.AlertType.WARNING,
	                    "No Selection",
	                    "Please select a loan to return.");
	            return;
	        }

	        Book book = selected.getBook();
	        Branch branch = book.getBranch();
	        if (branch == null) {
	            showAlert(Alert.AlertType.ERROR,
	                    "Error",
	                    "Branch information is missing for this book.");
	            return;
	        }

	       
	        system.returnBook(customer, branch.getId(), book.getId());

	        showAlert(Alert.AlertType.INFORMATION,
	                "Returned",
	                "You have returned: " + book.getTitle());


	        loadCurrentLoans();
	    }
	    
	    @FXML
	    private void handleRenewSelected() {
	        Loan selected = tblLoans.getSelectionModel().getSelectedItem();
	        
	        if (selected == null) {
	            showAlert(Alert.AlertType.WARNING, "No Selection", "Please select a loan to renew.");
	            return;
	        }

	        //  Call the Backend method
	        String result = system.renewLoan(selected);

	        // Handle the Result in UI 
	        switch (result) {
	            case "RESERVED":
	                showAlert(Alert.AlertType.INFORMATION,
	                        "Cannot Renew",
	                        "This book has other reservations and cannot be renewed.");
	                break;

	            case "LIMIT":
	                showAlert(Alert.AlertType.WARNING,
	                        "Renewal Limit Reached",
	                        "You have already renewed this loan more than 2 times.\n"
	                      + "It cannot be renewed again.");
	                break;

	            case "SUCCESS":
	                Book book = selected.getBook();
	                showAlert(Alert.AlertType.INFORMATION,
	                        "Renewed",
	                        "Your loan for '" + book.getTitle()
	                      + "' has been renewed.\nNew due date: "
	                      + selected.getDueDate().format(DATE_FMT));
	                tblLoans.refresh(); // Update the table view
	                break;

	            default:
	                showAlert(Alert.AlertType.ERROR, "Error", "An unknown error occurred.");
	        }
	    }
	   

	    @FXML
	    private void handleBackToMain(ActionEvent event) throws IOException {
	        FXMLLoader loader = new FXMLLoader(
	                getClass().getResource("customer-view.fxml"));
	        Parent root = loader.load();

	        Stage stage = (Stage) ((Node) event.getSource())
	                .getScene().getWindow();
	        
	        Scene scene = new Scene(root);


	        Main.applyAppStyles(scene);

	        stage.setScene(scene);
	     
	        stage.setTitle("Malden Library - Customer");
	        stage.show();
	    }

	    private void showAlert(Alert.AlertType type, String title, String msg) {
	        Alert alert = new Alert(type);
	        alert.setTitle(title);
	        alert.setHeaderText(null);
	        alert.setContentText(msg);
	        alert.showAndWait();
	    }

}
