package application;
import java.io.IOException;

import Library.Book;
import Library.Branch;
import Library.LibrarySystem;
import Library.Loan;
import Users.Customer;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import java.util.Optional;

import ADT.SBTArrayList;
import ADT.SBTBagADT;
import ADT.SBTComparator;
import ADT.SBTListADT;
import Users.Customer;

public class CustomerBorrowController {
	@FXML
    private TextField txtSearchTitle;

    @FXML
    private ComboBox<String> cmbSortBy;

    @FXML
    private TableView<Book> tblBooks;

    @FXML
    private TableColumn<Book, String> colId;

    @FXML
    private TableColumn<Book, String> colTitle;

    @FXML
    private TableColumn<Book, String> colAuthor;

    @FXML
    private TableColumn<Book, String> colCategory;

    @FXML
    private TableColumn<Book, String> colAvailable;

    private LibrarySystem system;
    private Customer customer;

    private SBTListADT<Book> allBooks = new SBTArrayList<>();
    private ObservableList<Book> tableData = FXCollections.observableArrayList();

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @FXML
    public void initialize() {
        system = Main.getSystem();


        colId.setCellValueFactory(cd ->
                new SimpleStringProperty(cd.getValue().getId()));
        colTitle.setCellValueFactory(cd ->
                new SimpleStringProperty(cd.getValue().getTitle()));
        colAuthor.setCellValueFactory(cd ->
                new SimpleStringProperty(cd.getValue().getAuthor()));
        colCategory.setCellValueFactory(cd ->
                new SimpleStringProperty(
                        cd.getValue().getBranch() != null
                                ? cd.getValue().getBranch().getName()
                                : ""));
        colAvailable.setCellValueFactory(cd ->
                new SimpleStringProperty(cd.getValue().isAvailable()
                        ? "Yes" : "No"));


        cmbSortBy.getItems().addAll("Title", "Author", "Category");
        cmbSortBy.getSelectionModel().selectFirst();


        loadAllBooks();


        txtSearchTitle.textProperty().addListener((obs, oldV, newV) -> {
            applyFilterAndSort();
        });


        cmbSortBy.valueProperty().addListener((obs, oldV, newV) -> {
            applyFilterAndSort();
        });


        applyFilterAndSort();
    }


 
    private void loadAllBooks() {
    	
        allBooks.clear();

        // ADT.List<Branch> 
        Object[] branchObjs = system.getAllBranches().toArray();
        // start recursive traversal at index 0
        recursiveLoadBranches(branchObjs, 0);
    }

    // recursively traverse branches array and for each branch traverse its books
    private void recursiveLoadBranches(Object[] branchObjs, int bidx) 
    {
        if (branchObjs == null || bidx >= branchObjs.length) 
        {return;
        }
        
        Branch b = (Branch) branchObjs[bidx];
        
        if (b != null) {
            Object[] bookObjs = b.getAllBooks().toArray();
            // traverse books for this branch recursively
            recursiveLoadBooks(bookObjs, 0);
        }
        // recurse to next branch
        recursiveLoadBranches(branchObjs, bidx + 1);
    }

    // recursively traverse a book Object[] and add each Book to allBooks
    private void recursiveLoadBooks(Object[] bookObjs, int idx) {
        if (bookObjs == null || idx >= bookObjs.length) {
        	return;
        }
        Book book = (Book) bookObjs[idx];
        
        if (book != null) {
            allBooks.add(book);
        }
        
        recursiveLoadBooks(bookObjs, idx + 1);
    }



    private void applyFilterAndSort() {
  
        String keyword = txtSearchTitle.getText();
        if (keyword == null) {
            keyword = "";
        }
        String kwLower = keyword.toLowerCase();


        ADT.SBTListADT<Book> filtered = new ADT.SBTArrayList<>();


        Object[] allObjs = allBooks.toArray();
        for (int i = 0; i < allObjs.length; i++) {
            Book book = (Book) allObjs[i];
            if (book != null && book.getTitle() != null
                    && book.getTitle().toLowerCase().contains(kwLower)) {
                filtered.add(book);
            }
        }

    
        Object[] filteredObjs = filtered.toArray();
        Book[] array = new Book[filteredObjs.length];
        for (int i = 0; i < filteredObjs.length; i++) {
            array[i] = (Book) filteredObjs[i];
        }


        String sortBy = cmbSortBy.getValue();

        ADT.SBTComparator<Book> comp;

        if ("Author".equals(sortBy)) {

            comp = new ADT.SBTComparator<Book>() {
                @Override
                public int compare(Book b1, Book b2) {
                    String s1 = b1 != null ? b1.getAuthor() : null;
                    String s2 = b2 != null ? b2.getAuthor() : null;
                    if (s1 == null && s2 == null) {
                    	return 0;
                    }
                    if (s1 == null) {
                    	return -1;
                    }
                    if (s2 == null) {
                    	return 1;
                    }
                    
                    return s1.compareToIgnoreCase(s2);
                }
            };
        } else if ("Category".equals(sortBy)) {
       
            comp = new ADT.SBTComparator<Book>() {
                @Override
                public int compare(Book b1, Book b2) {
                    String c1 = "";
                    String c2 = "";
                    if (b1 != null && b1.getBranch() != null) {
                        c1 = b1.getBranch().getName();
                    }
                    
                    if (b2 != null && b2.getBranch() != null) {
                        c2 = b2.getBranch().getName();
                    }
                    
                    if (c1 == null && c2 == null) {
                    	return 0;
                    }
                    
                    if (c1 == null) {
                    	return -1;
                    }
                    
                    if (c2 == null) {
                    	return 1;
                    }
                    
                    return c1.compareToIgnoreCase(c2);
                }
            };
        } else {

            comp = new ADT.SBTComparator<Book>() {
                @Override
                public int compare(Book b1, Book b2) {
                    String t1 = b1 != null ? b1.getTitle() : null;
                    String t2 = b2 != null ? b2.getTitle() : null;
                    if (t1 == null && t2 == null) {
                    	return 0;
                    }
                    
                    if (t1 == null) {
                    	return -1;
                    }
                    
                    if (t2 == null) {
                    	return 1;
                    }
                    
                    return t1.compareToIgnoreCase(t2);
                }
            };
        }

    
        insertionSort(array, comp);

    
        tableData.setAll(array);
        tblBooks.setItems(tableData);
        tblBooks.refresh();
    }



    private void insertionSort(Book[] a, SBTComparator<Book> comp) {
        for (int unsorted = 1; unsorted < a.length; unsorted++) {
            Book nextToInsert = a[unsorted];
            int index = unsorted - 1;
            while (index >= 0 && comp.compare(nextToInsert, a[index]) < 0) {
                a[index + 1] = a[index];
                index--;
            }
            a[index + 1] = nextToInsert;
        }
    }

    @FXML
    private void handleBorrowSelected() {
    	
    	Book selected = tblBooks.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING,
                    "No Selection",
                    "Please select a book to borrow.");
            return;
        }

        if (customer == null) {
            showAlert(Alert.AlertType.ERROR,
                    "Error",
                    "No customer logged in.");
            return;
        }

        if (alreadyBorrowed(selected)) {
            showAlert(Alert.AlertType.WARNING,
                    "Already Borrowed",
                    "You cannot borrow the same book '" + selected.getTitle()
                  + "' another time.");
            return;
        }

        if (!selected.isAvailable()) {
            showAlert(Alert.AlertType.INFORMATION,
                    "Book Not Available",
                    "This book is currently not available. You can reserve it instead.");
            return;
        }

        String branchId = selected.getBranch().getId();
        String bookId   = selected.getId();
        system.borrowBook(customer, branchId, bookId);

        showAlert(Alert.AlertType.INFORMATION,
                "Borrowed",
                "You have borrowed: " + selected.getTitle());

        loadAllBooks();
        applyFilterAndSort();
    }
    
    
    private boolean alreadyBorrowed(Book book) {
        Loan[] loans = system.getCustomerLoans(customer);
        for (Loan loan : loans) {
            if (loan.getBook().equals(book) &&
                (loan.getStatus() == Loan.Status.BORROWED
              || loan.getStatus() == Loan.Status.RENEWED)) {
                return true;
            }
        }
        return false;
    }


    
    @FXML
    private void handleAddToWishList() {
        Book selected = tblBooks.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING,
                    "No Selection",
                    "Please select a book to add to your WishList.");
            return;
        }
        Customer cur = (Customer) Main.getCurrentUser();
        if (cur == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "No customer logged in.");
            return;
        }
        
     
        if (cur.isInWishList(selected)) {
            showAlert(
                    Alert.AlertType.ERROR,
                    "Already in WishList",
                    "You cannot add the same book repeatedly.\n\n"
                  + "'" + selected.getTitle() + "' is already in your WishList."
            );
            return;
        }
        

        if (alreadyBorrowed(selected)) {
            showAlert(Alert.AlertType.ERROR,
                    "Already Borrowed",
                    selected.getTitle() + " was borrowed. You cannot add it into the list again.");
            return;
        }

  
        cur.addToWishList(selected);
        showAlert(Alert.AlertType.INFORMATION,
                "Added to WishList",
                "'" + selected.getTitle() + "' has been added to your WishList.");
    }

    @FXML
    private void handleBackToMain(javafx.event.ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("customer-view.fxml"));
        Parent root = loader.load();

  
        CustomerController controller = loader.getController();
        controller.initialize(); 

        Stage stage = (Stage) ((Node) event.getSource())
                .getScene().getWindow();
        
        Scene scene = new Scene(root);


        Main.applyAppStyles(scene);

        stage.setScene(scene);

        stage.setTitle("Malden Library - Customer");
        stage.show();
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
    
    @FXML
    private void handleViewDetails() {
        Book selected = tblBooks.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(AlertType.WARNING,
                    "No Selection",
                    "Please select a book to view details.");
            return;
        }

        String title = selected.getTitle();
        String author = selected.getAuthor();
        String category = (selected.getBranch() != null)
                ? selected.getBranch().getName()
                : "N/A";
        boolean available = selected.isAvailable();
        int waitSize = selected.getWaitingListSize();

        String status = available ? "On Shelf" : "Checked Out";

        StringBuilder content = new StringBuilder();
        content.append("Title: ").append(title).append("\n")
               .append("Author: ").append(author).append("\n")
               .append("Category: ").append(category).append("\n\n")
               .append("Status: ").append(status).append("\n")
               .append("Waitlist: ").append(waitSize)
               .append(waitSize == 1 ? " person" : " people");

        ButtonType btnPlaceHold = new ButtonType("Place Hold");
        ButtonType btnClose = new ButtonType("Close", ButtonType.CANCEL.getButtonData());

        Alert dialog = new Alert(AlertType.INFORMATION);
        dialog.setTitle("Book Details");
        dialog.setHeaderText(title);
        dialog.setContentText(content.toString());
        dialog.getButtonTypes().setAll(btnPlaceHold, btnClose);

        Optional<ButtonType> result = dialog.showAndWait();

        if (result.isPresent() && result.get() == btnPlaceHold) {
            Customer customer = (Customer) Main.getCurrentUser();
            if (customer == null) {
                showAlert(AlertType.ERROR,
                        "Error",
                        "Current user is not a customer.");
                return;
            }
            
            SBTBagADT<Loan> currentLoans = customer.getCurrentLoans();
            Object[] loanArray = currentLoans.toArray();
            for (Object obj : loanArray) {
                Loan loan = (Loan) obj;
                if (loan.getBook().getId().equals(selected.getId()) && 
                    loan.getStatus() != Loan.Status.RETURNED) {
                    showAlert(AlertType.ERROR,
                            "Already Borrowed",
                            " You have already borrowed " + selected.getTitle() + ". No need to place hold on it.");
                    return;
                }
            }


            if (available) {
                showAlert(AlertType.INFORMATION,
                        "On Shelf",
                        "This book is currently on shelf. You can borrow it directly.");
                return;
            }

            int before = selected.getWaitingListSize();
            selected.addToWaitingList(customer);
            int after = selected.getWaitingListSize();

            customer.addToWishList(selected);
            

            showAlert(AlertType.INFORMATION,
                    "Hold Placed",
                    "The book has been added to your WishList:\n" + title
                  +  "\nWaitlist before: " + before
                  + "\nWaitlist after: " + after);
        }
    }

}
