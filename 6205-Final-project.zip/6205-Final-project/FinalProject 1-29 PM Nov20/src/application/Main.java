package application;
	
import Library.LibraryDemoData;
import Library.LibrarySystem;
import Users.User;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;

import java.io.IOException;


public class Main extends Application {
	private static LibrarySystem system = new LibrarySystem();

    
    private static User currentUser;
    
    public static final String APP_STYLESHEET =
            Main.class.getResource("librarytheme.css").toExternalForm();

    public static void applyAppStyles(Scene scene) {
        if (!scene.getStylesheets().contains(APP_STYLESHEET)) {
            scene.getStylesheets().add(APP_STYLESHEET);
        }
    }

    public static LibrarySystem getSystem() {
        return system;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static void setCurrentUser(User user) {
        currentUser = user;
    }
	@Override
	public void start(Stage primaryStage) {
		try {
//			//system.initializeDemoData();
		
            if (system == null) {
                system = new LibrarySystem();
            }


			LibraryDemoData dataLoader = new LibraryDemoData();
			dataLoader.loadDemoData(system);

			Parent root = FXMLLoader.load(getClass().getResource("login-view.fxml"));
	
	        Scene scene = new Scene(root);
	 
	        applyAppStyles(scene);
//	        scene.getStylesheets().add(
//	                getClass().getResource("librarytheme.css").toExternalForm()
//	        );

	        primaryStage.setScene(scene);
	        primaryStage.show();
	        primaryStage.setTitle("Library System - Login");
	        primaryStage.setScene(scene);
	        primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
    @Override
    public void stop() {
        try {
            // Wishlist persistence disabled. Commented out to avoid calling removed methods in LibrarySystem.
//            system.saveWishlistsToFile("wishlists.txt");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

	public static void main(String[] args) {
		launch(args);
	}
}