package application;
import java.io.IOException;

import ADT.SBTArrayList;
import ADT.SBTListADT;
import Library.Book;
import Library.Branch;
import Library.LibrarySystem;
import Library.Loan;
import Users.Customer;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
public class CustomerWishListController {
    @FXML
    private TableView<Book> tblHolds;

    @FXML
    private TableColumn<Book, String> colTitle;

    @FXML
    private TableColumn<Book, String> colBranch;

    @FXML
    private TableColumn<Book, String> colWaitSize;

    @FXML
    private TableColumn<Book, String> colAvailable;
    
    @FXML
    private TableColumn<Book, String> colStatus;
    


    private LibrarySystem system;
    private Customer customer;

    private final ObservableList<Book> tableData =
            FXCollections.observableArrayList();

    public void setCustomer(Customer customer) {
        this.customer = customer;
        if (system != null) {
            loadMyHolds();
        }
    }

    @FXML
    public void initialize() {
        system = Main.getSystem();
        if (Main.getCurrentUser() instanceof Customer && customer == null) {
            customer = (Customer) Main.getCurrentUser();
        }

        colTitle.setCellValueFactory(cd ->
                new SimpleStringProperty(cd.getValue().getTitle()));

        colBranch.setCellValueFactory(cd ->
                new SimpleStringProperty(
                        cd.getValue().getBranch() != null
                                ? cd.getValue().getBranch().getName()
                                : ""));

        colWaitSize.setCellValueFactory(cd ->
                new SimpleStringProperty(
                        String.valueOf(cd.getValue().getWaitingListSize())));

        colAvailable.setCellValueFactory(cd ->
                new SimpleStringProperty(cd.getValue().isAvailable() ? "Yes" : "No"));
        
        
     // Status column: show Frozen (if frozen for current customer), Waiting (if on waiting list),
     // or Active otherwise.
     colStatus.setCellValueFactory(cd -> {
         Book book = cd.getValue();
         Customer cur = this.customer != null
                 ? this.customer
                 : (Main.getCurrentUser() instanceof Customer ? (Customer) Main.getCurrentUser() : null);
         String status;
         if (cur != null && book.isHoldFrozen(cur)) {
             status = "Frozen";
         } else if (cur != null && book.isOnWaitingList(cur)) {
             status = "Waiting";
         } else {
        	 status = book.isAvailable() ? "On Shelf" : "Checked Out";
         }
         return new SimpleStringProperty(status);
     });

        tblHolds.setItems(tableData);

        if (customer != null) {
            loadMyHolds();
        }
    }

    private void loadMyHolds() {
        tableData.clear();
        if (customer == null) return;

        // Load from the customer's wish list bag
        ADT.SBTBagADT<Book> bag = customer.getWishList();
        if (bag == null) return;
        Object[] objs = bag.toArray();
        Book[] arr = new Book[objs.length];
        for (int i = 0; i < objs.length; i++) {
            arr[i] = (Book) objs[i];
        }
        tableData.setAll(arr);
        tblHolds.refresh();
    }


    @FXML
    private void handleCancelHold() {
        Book selected = tblHolds.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING,
                    "No Selection",
                    "Please select a book to cancel hold.");
            return;
        }
        
        if (selected.isAvailable()) {
            showAlert(Alert.AlertType.ERROR,
                    "Book Available",
                    "This book is currently available.\n"
                  + "You can borrow it directly. No need to place or freeze a hold.");
            return;
        }

        selected.cancelHold(customer);
        showAlert(Alert.AlertType.INFORMATION,
                "Hold Cancelled",
                "Your hold for '" + selected.getTitle() + "' has been cancelled.");

        loadMyHolds();
    }
    
    @FXML
    private void handleFreezeHold() {
        Book selected = tblHolds.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING,
                    "No Selection",
                    "Please select a book to freeze hold.");
            return;
        }

        // Ensure we have a customer (try current user as fallback)
        if (customer == null) {
            if (Main.getCurrentUser() instanceof Customer) {
                customer = (Customer) Main.getCurrentUser();
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "No customer set.");
                return;
            }
        }

        if (selected.isAvailable()) {
            showAlert(Alert.AlertType.ERROR,
                    "Book Available",
                    "This book is currently available.\n"
                  + "You can borrow it directly. No need to place or freeze a hold.");
            return;
        }

        // If user is not on the waiting list, offer to place a hold then freeze it
        if (!selected.isOnWaitingList(customer)) {
            javafx.scene.control.Alert confirm = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Not on Waitlist");
            confirm.setHeaderText("You are not on the waiting list for this book.");
            confirm.setContentText("Would you like to place a hold (be added to the waitlist) and then freeze it?");
            javafx.scene.control.ButtonType yes = new javafx.scene.control.ButtonType("Yes");
            javafx.scene.control.ButtonType no = new javafx.scene.control.ButtonType("No", javafx.scene.control.ButtonType.CANCEL.getButtonData());
            confirm.getButtonTypes().setAll(yes, no);

            java.util.Optional<javafx.scene.control.ButtonType> resp = confirm.showAndWait();
            if (resp.isPresent() && resp.get() == yes) {
                selected.addToWaitingList(customer);
                customer.addToWishList(selected);
                selected.freezeHold(customer);
                showAlert(Alert.AlertType.INFORMATION, "Hold Placed & Frozen",
                        "Your hold for '" + selected.getTitle() + "' has been placed and frozen.");
                loadMyHolds();
            }
            return;
        }

        // already on waiting list: just freeze
        selected.freezeHold(customer);
        showAlert(Alert.AlertType.INFORMATION,
                "Hold Frozen",
                "Your hold for '" + selected.getTitle() + "' has been frozen.");

        loadMyHolds();
    }
    
    @FXML
    private void handleUnfreezeHold() {
        Book selected = tblHolds.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING,
                    "No Selection",
                    "Please select a book to unfreeze hold.");
            return;
        }

        // Ensure we have a customer (try current user as fallback)
        if (customer == null) {
            if (Main.getCurrentUser() instanceof Customer) {
                customer = (Customer) Main.getCurrentUser();
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "No customer set.");
                return;
            }
        }

        if (!selected.isOnWaitingList(customer)) {
            showAlert(Alert.AlertType.INFORMATION,
                    "Not on Waitlist",
                    "You are not on the waiting list for '" + selected.getTitle() + "'.");
            return;
        }


        if (!selected.isHoldFrozen(customer)) {
            showAlert(Alert.AlertType.INFORMATION,
                    "Hold Not Frozen",
                    "Your hold for '" + selected.getTitle() + "' is already active (not frozen).");
            return;
        }

 
        selected.unfreezeHold(customer);
        showAlert(Alert.AlertType.INFORMATION,
                "Hold Unfrozen",
                "Your hold for '" + selected.getTitle() + "' has been unfrozen.");

        loadMyHolds();
    }


    @FXML
    private void handleRemoveFromWishList() {
        Book selected = tblHolds.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING,
                    "No Selection",
                    "Please select a book to remove from your WishList.");
            return;
        }

        if (customer == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "No customer set.");
            return;
        }

        customer.removeFromWishList(selected);
        showAlert(Alert.AlertType.INFORMATION, "Removed", "'" + selected.getTitle() + "' removed from your WishList.");
        loadMyHolds();
    }
    
    	
    @FXML
    private void handleBorrowSelectedFromWishList() {
        Book selected = tblHolds.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING,
                    "No Selection",
                    "Please select a book to borrow.");
            return;
        }

        if (customer == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "No customer set.");
            return;
        }
        
        if (!selected.isAvailable()) {
            showAlert(Alert.AlertType.ERROR, "Error", "This book is not available and cannot be borrowed.");
            return;
        }
        
        

        // If the book is available and nobody is waiting, try to borrow it via LibrarySystem
        if (selected.isAvailable() && selected.getWaitingListSize() == 0) {
            String branchId = selected.getBranch() != null ? selected.getBranch().getId() : null;
            String bookId = selected.getId();
            if (branchId == null || bookId == null) {
                showAlert(Alert.AlertType.ERROR, "Error", "Book or branch information is missing.");
                return;
            }

            Loan loan = system.borrowBook(customer, branchId, bookId);
            if (loan == null) {
                showAlert(Alert.AlertType.ERROR, "Borrow Failed", "Unable to borrow the selected book.");
                return;
            }

            // Remove from wishlist after successful borrow
            customer.removeFromWishList(selected);
           
            showAlert(Alert.AlertType.INFORMATION,
                    "Borrowed",
                    "You have borrowed: " + selected.getTitle());

            loadMyHolds();
            return;
        }

        // If already on waiting list, inform and remove from wishlist (optional)
        if (selected.isOnWaitingList(customer)) {
            customer.removeFromWishList(selected);
            showAlert(Alert.AlertType.INFORMATION,
                    "Already Waiting",
                    "You are already on the waiting list for '" + selected.getTitle() + "'. It has been removed from your WishList.");
            loadMyHolds();
            return;
        }

        // Otherwise (book is checked out or others are waiting), add to waiting list (normal reservation)
        selected.addToWaitingList(customer);
        customer.removeFromWishList(selected);

        showAlert(Alert.AlertType.INFORMATION,
                "Reserved",
                "You have been added to the waiting list for: '" + selected.getTitle() + "'.");

        loadMyHolds();
    }



    @FXML
    private void handleBackToMain(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(
                getClass().getResource("customer-view.fxml"));
        Stage stage = (Stage) ((Node) event.getSource())
                .getScene().getWindow();
  
        
        Scene scene = new Scene(root);


        Main.applyAppStyles(scene);

        stage.setScene(scene);
        stage.setTitle("Malden Library - Customer");
        stage.show();
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}