package application;

import java.io.IOException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import Users.Customer;
import Library.Loan;
import Library.LibrarySystem;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

public class CustomerOverdueController {
    private Customer customer;

    @FXML
    private Label lblMessage;

 
    @FXML
    private TableView<Loan> tblOverdues;

    @FXML
    private TableColumn<Loan, String> colBook;      
    @FXML
    private TableColumn<Loan, String> colDueDate;   
    @FXML
    private TableColumn<Loan, String> colDaysOver;  


    @FXML
    private void initialize() {

        colBook.setCellValueFactory(cellData -> {
            Loan loan = cellData.getValue();
            String text = loan.getBook().getTitle()
                    + " (ID: " + loan.getBook().getId() + ")";
            return new SimpleStringProperty(text);
        });


        colDueDate.setCellValueFactory(cellData -> {
            Loan loan = cellData.getValue();
            LocalDate due = loan.getDueDate();
            String text = (due != null) ? due.toString() : "";
            return new SimpleStringProperty(text);
        });


        colDaysOver.setCellValueFactory(cellData -> {
            Loan loan = cellData.getValue();
            LocalDate due = loan.getDueDate();
            if (due == null) {
                return new SimpleStringProperty("");
            }
            long days = ChronoUnit.DAYS.between(due, LocalDate.now());
            String text = (days > 0) ? String.valueOf(days) : "0";
            return new SimpleStringProperty(text);
        });
    }



    public void setCustomer(Customer c) {
        this.customer = c;
        loadOverdues();
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        loadOverdues();
    }

    private void loadOverdues() {

        if (tblOverdues != null) {
            tblOverdues.getItems().clear();
        }

        if (customer == null) {
            if (lblMessage != null) {
                lblMessage.setText("No customer information available.");
            }
            return;
        }

        LibrarySystem system = Main.getSystem();
        if (system == null) {
            if (lblMessage != null) {
                lblMessage.setText("System not available.");
            }
            return;
        }

        Loan[] loans = system.getCustomerLoans(customer);
        ObservableList<Loan> overdueList = FXCollections.observableArrayList();
        LocalDate today = LocalDate.now();


        for (Loan loan : loans) {
            if (loan == null) continue;
            if (loan.getDueDate() != null && loan.getDueDate().isBefore(today)) {
                overdueList.add(loan);
            }
        }

        if (overdueList.isEmpty()) {
            if (lblMessage != null) {
                lblMessage.setText("No overdue items for " + customer.getUserName());
            }
        } else {
            if (lblMessage != null) {
                lblMessage.setText("Overdue items for " + customer.getUserName() + ":");
            }
            if (tblOverdues != null) {
                tblOverdues.setItems(overdueList);
            }
        }
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("customer-view.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);


        Main.applyAppStyles(scene);

        stage.setScene(scene);
      
        stage.setTitle("Customer Dashboard");
        stage.show();
    }
}
