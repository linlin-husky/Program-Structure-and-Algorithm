package application;
import java.io.IOException;

import Library.LibrarySystem;
import Users.Customer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.animation.PauseTransition;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
public class CustomerController {
    private LibrarySystem system;
    private Customer currentCustomer;
    @FXML
    private Label lblUserName; 
    @FXML
    private Button btnMyHolds; // injected from FXML; used to locate the parent container

    @FXML
    public void initialize() {
        system = Main.getSystem();
    
        currentCustomer = (Customer) Main.getCurrentUser();
        lblUserName.setText("Welcome, " + currentCustomer.getUserName());
        // Programmatically find the OverDue button (by its displayed text) and attach an action that gives visual feedback
        try {
            Parent parent = btnMyHolds.getParent();
            if (parent instanceof Pane) {
                for (Node n : ((Pane) parent).getChildren()) {
                    if (n instanceof Button) {
                        Button b = (Button) n;
                        if ("OverDue".equals(b.getText())) {
                            b.setOnAction((ActionEvent event) -> {
                                String old = b.getText();
                                b.setText("Opening...");
                                try {
                                    handleOverdue(event);
                                } catch (IOException ex) {
                                    ex.printStackTrace();
                                }
                                PauseTransition pt = new PauseTransition(Duration.millis(700));
                                pt.setOnFinished(ev -> b.setText(old));
                                pt.play();
                            });
                            break;
                        }
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    @FXML
    private void handleBorrow(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("customer-borrow-view.fxml"));
        Parent root = loader.load();


        CustomerBorrowController controller = loader.getController();
        controller.setCustomer(currentCustomer);

        Stage stage = (Stage) ((Node) event.getSource())
                .getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.setTitle("Borrow Books");
        stage.show();
    }

    @FXML
    private void handleReturn(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("customer-return-view.fxml"));
        Parent root = loader.load();

        CustomerReturnController controller = loader.getController();
        controller.setCustomer(currentCustomer);

        Stage stage = (Stage) ((Node) event.getSource())
                .getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.setTitle("Return Books");
        stage.show();
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        Main.setCurrentUser(null);
        Parent root = FXMLLoader.load(
                getClass().getResource("login-view.fxml"));
        Stage stage = (Stage) ((Node) event.getSource())
                .getScene().getWindow();
         Scene scene = new Scene(root);
        
        Main.applyAppStyles(scene);

        stage.setScene(scene);
    
        stage.setTitle("Smart Borrowing System - Login");
        stage.show();
    }

    @FXML
    private void handleMyHolds(ActionEvent event) throws IOException {
        // Open the My WishList view (migrated styled version)
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("customer-holds-view.fxml"));
            Parent root = loader.load();

            CustomerWishListController controller = loader.getController();
            controller.setCustomer((Customer) Main.getCurrentUser());

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("My WishList");
            stage.show();
        } catch (Exception ex) {
            ex.printStackTrace();
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setTitle("Error opening My WishList");
            a.setHeaderText("Could not open My WishList");
            a.setContentText(ex.getClass().getName() + ": " + ex.getMessage());
            a.showAndWait();
        }
    }

    @FXML
    private void handleReadyToPickUp(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("customer-ready-view.fxml"));
        Parent root = loader.load();

        CustomerReadyController controller = loader.getController();
        controller.setCustomer((Customer) Main.getCurrentUser());

        Stage stage = (Stage) ((Node) event.getSource())
                .getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.setTitle("Ready to Pick Up");
        stage.show();
    }

    @FXML
    public void handleOverdue(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("customer-overdue-view.fxml"));
        Parent root = loader.load();

        CustomerOverdueController controller = loader.getController();
        controller.setCustomer((Customer) Main.getCurrentUser());

        Stage stage = (Stage) ((Node) event.getSource())
                .getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.setTitle("Overdue");
        stage.show();
    }

}