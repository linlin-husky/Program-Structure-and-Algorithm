package application;
import java.io.IOException;

import Library.LibrarySystem;
import Users.User;
import Users.UserRole;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
public class LoginController {
	@FXML
    private TextField txtUsername;

    @FXML
    private PasswordField txtPassword;

    @FXML
    private Label lblError;

    private LibrarySystem system;

    @FXML
    public void initialize() {
        
        system = Main.getSystem();
    }

    @FXML
    private void handleLogin(ActionEvent event) throws IOException {
        String username = txtUsername.getText();
        String password = txtPassword.getText();

        if (username == null || username.isBlank()
                || password == null || password.isBlank()) {
            lblError.setText("Please input the username and password.");
            return;
        }

        User user = system.login(username, password);
        if (user == null) {
            lblError.setText("The username or password is invaild.");
            return;
        }

        
        Main.setCurrentUser(user);

        
        String fxml;
        
        if (user.getRole() == UserRole.MANAGER) {
            fxml = "manager-main-view.fxml";
        } else if (user.getRole() == UserRole.ADMIN) {
            fxml = "admin-view.fxml";  
        } else {
            fxml = "customer-view.fxml"; 
        }
        
        
        
        Stage stage = (Stage) ((Node) event.getSource())
                .getScene().getWindow();
        Parent root = FXMLLoader.load(
                getClass().getResource(fxml));
        stage.setScene(new Scene(root));
        stage.show();
    }
}
