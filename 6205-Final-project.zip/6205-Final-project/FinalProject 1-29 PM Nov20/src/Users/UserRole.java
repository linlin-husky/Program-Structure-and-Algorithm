package Users;

public enum UserRole {
	CUSTOMER,
    MANAGER,
    ADMIN
}
