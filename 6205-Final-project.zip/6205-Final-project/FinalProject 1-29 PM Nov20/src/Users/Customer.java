package Users;

import ADT.SBTResizableBag;
import ADT.SBTBagADT;
import Library.Loan;

public class Customer extends User{
	private SBTBagADT<Loan> currentLoans = new SBTResizableBag<>();
	public Customer(String id,
            String name,
            String email,
            String username,
            String password) {
	super(id, name, email, username, password, UserRole.CUSTOMER);
	}
	
	@Override
	public UserRole getRole() {
	
		return UserRole.CUSTOMER;
	}
	
	@Override
	public boolean canBorrowBooks() {
		return true;
	}
	
	@Override
	public boolean canReserveBooks() {
		return true;
	}
	public void addLoan(Loan loan) {
        if (loan != null) {
            currentLoans.add(loan);
        }
    }

    public void removeLoan(Loan loan) {
        if (loan != null) {
            currentLoans.remove(loan);
        }
    }

    public SBTBagADT<Loan> getCurrentLoans() {
        return currentLoans;
    }

    public int getCurrentLoanCount() {
        return currentLoans.getCurrentSize();
    }

    // WishList feature: store books the customer is interested in regardless of availability
    private ADT.SBTBagADT<Library.Book> wishList = new ADT.SBTResizableBag<>();

    /**
     * Add book to wishlist if not already present. Returns true if added, false if already present.
     */
    public boolean addToWishList(Library.Book book) {
        if (book == null) return false;
        if (wishList.contains(book)) return false;
        return wishList.add(book);
    }

    public void removeFromWishList(Library.Book book) {
        if (book != null) {
            wishList.remove(book);
        }
    }
    
    public boolean isInWishList(Library.Book book) {
        if (book == null || wishList == null) {
            return false;
        }


        Object[] arr = wishList.toArray();
        for (Object o : arr) {
        	Library.Book b = (Library.Book) o;

            if (b != null && b.getId().equals(book.getId())) {
                return true;
            }
        }
        return false;
    }


    public ADT.SBTBagADT<Library.Book> getWishList() {
        return wishList;
    }

    // Compatibility alias: some controllers call getUserName()
    public String getUserName() {
        return getUsername();
    }
}