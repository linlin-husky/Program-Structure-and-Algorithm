package Users;

public class Admin extends User{
    public Admin(String id,
            String name,
            String email,
            String username,
            String password) {
    super(id, name, email, username, password, UserRole.ADMIN);
	}
	
	@Override
	public UserRole getRole() {
	   return UserRole.ADMIN;
	}
	
	@Override
	public boolean canManageUsers() {
	   return true;
	}
	
	@Override
	public boolean canManageBooks() {
	   return true;
	}
	
	@Override
	public boolean canBorrowBooks() {
	   return false;
	}
	
	@Override
	public boolean canReserveBooks() {
	   return false;
	}

}
