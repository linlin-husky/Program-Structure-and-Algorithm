package Users;

public class Manager extends User{
    public Manager(String id,
            String name,
            String email,
            String username,
            String password) {
	 super(id, name, email, username, password, UserRole.MANAGER);
	}
	
	@Override
	public UserRole getRole() {
		return UserRole.MANAGER;
	}
	
	@Override
	public boolean canManageBooks() {
		return true;
	}
	
	@Override
	public boolean canBorrowBooks() {
	 
		return false;
	}
	
	@Override
	public boolean canReserveBooks() {
		return false;
	}
}
