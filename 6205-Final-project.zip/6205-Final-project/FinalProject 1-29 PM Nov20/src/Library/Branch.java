package Library;

import ADT.SBTMapADT;
import ADT.SBTHashMap;
import ADT.SBTListADT;
import ADT.SBTArrayList;

// here branch means the category to which a book belongs such as Art and Design
public class Branch {
    private final String id;
    private String name;
    private final SBTMapADT<String, Book> booksById = new SBTHashMap<>(); // program to interface

    public Branch(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public void addBook(Book book) {
        if (book != null) {
            booksById.put(book.getId(), book);
        }
    }

    public Book findBook(String bookId) {
        if (bookId == null) return null;
        return booksById.get(bookId);
    }

    public SBTListADT<Book> getAllBooks() {
        return booksById.values();
    }


    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
