package Library;


import ADT.SBTHashMap;
import ADT.SBTListADT;
import ADT.SBTMapADT;



public class BranchCollection {
    // Clear about implementation: uses HashMap internally (hashing)
    private final SBTMapADT<String, Branch> map = new SBTHashMap<>();

    /**
     * Create and add a new Branch with given id and name. If an entry with the
     * same id already exists, it will be replaced and the previous Branch is
     * returned.
     */
    public Branch addBranch(String id, String name) {
        Branch b = new Branch(id, name);
        map.put(id, b);
        return b;
    }

    /** Return the branch with the given id, or null if not found. */
    public Branch getBranch(String id) {
        return map.get(id);
    }

    /** Return an independent list copy of all branches. */
    public SBTListADT<Branch> getAllBranches() {
         return map.values();
    }

    /** Remove the branch with given id. Returns true if removed. */
    public boolean removeBranch(String id) {
        return map.remove(id) != null;
    }

    /** Check whether a branch with the given id exists. */
    public boolean containsId(String id) {
        return map.containsKey(id);
    }

    /** Return an unmodifiable view of the underlying id->branch map. */
    public SBTMapADT<String, Branch> asUnmodifiableMap() {
        return map;
    }
}
