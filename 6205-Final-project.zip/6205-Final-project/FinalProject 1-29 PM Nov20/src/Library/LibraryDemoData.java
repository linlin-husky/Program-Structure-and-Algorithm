package Library;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;

import Users.Admin;
import Users.Customer;
import Users.Manager;
import Users.User;

public class LibraryDemoData {
    public void loadDemoData(LibrarySystem system) {
        if (system == null) return;

        // Try loading from CSV first (developer-friendly). If absent, fall back to hard-coded demo.
        File csv = new File("src/Library/demo_data.csv");
        if (csv.exists()) {
            try {
                loadFromCsv(system, csv);
                System.out.println("Loaded demo data from: " + csv.getPath());
                return;
            } catch (Exception e) {
                System.out.println("Failed to load demo CSV, falling back to built-in demo data: " + e.getMessage());
                e.printStackTrace();
            }
        }

        // FALLBACK: original hard-coded demo generation (keeps previous behavior)
        // ---- 1. create branches ----
        BranchCollection bookBranch = system.getBranches();

        Branch b1 = bookBranch.addBranch("B1", "Novel");
        Branch b2 = bookBranch.addBranch("B2", "Computer Science");
        Branch b3 = bookBranch.addBranch("B3", "History");
        Branch b4 = bookBranch.addBranch("B4", "Art & Design");

        Branch[] branchArray = new Branch[] { b1, b2, b3, b4 };

        // ---- 2. create 50 books ----
        for (int i = 1; i <= 50; i++) {
            Branch branch = branchArray[(i - 1) % branchArray.length];

            String id = "BK" + i;
            String title;
            switch ((i - 1) % 4) {
                case 0:
                    title = "Novel Story " + i;
                    break;
                case 1:
                    title = "Java / CS Topic " + i;
                    break;
                case 2:
                    title = "World History " + i;
                    break;
                default:
                    title = "Art & Design " + i;
            }

            String author = "Author " + ((i - 1) % 10 + 1);

            Book book = new Book(id, title, author, branch);
            branch.addBook(book);
        }

        // ---- 3. create users ----
        Customer c1 = new Customer("C1", "Tom", "tom@example.com", "tom", "123");
        Customer c2 = new Customer("C2", "Jerry", "jerry@example.com", "jerry", "123");
        // Additional demo customers so we can populate longer waitlists
        Customer c3 = new Customer("C3", "Alice", "alice@example.com", "alice", "123");
        Customer c4 = new Customer("C4", "Bob", "bob@example.com", "bob", "123");
        Customer c5 = new Customer("C5", "Carol", "carol@example.com", "carol", "123");
        Customer c6 = new Customer("C6", "Dave", "dave@example.com", "dave", "123");
        system.registerUser(c1);
        system.registerUser(c2);
        system.registerUser(c3);
        system.registerUser(c4);
        system.registerUser(c5);
        system.registerUser(c6);

        Manager m1 = new Manager("M1", "Manager Alice", "manager@example.com", "manager", "123");
        system.registerUser(m1);
        Admin admin = new Admin("A1", "System Admin", "admin@example.com", "admin", "123");
        system.registerUser(admin);

        // ---- 4. borrow some books ----
        Loan l1 = system.borrowBook(c1, "B1", "BK1");
        Loan l2 = system.borrowBook(c1, "B2", "BK2");
        Loan l3 = system.borrowBook(c1, "B3", "BK3");

        Loan l4 = system.borrowBook(c2, "B1", "BK4");
        Loan l5 = system.borrowBook(c2, "B2", "BK5");

        LocalDate today = LocalDate.now();
        if (l1 != null) l1.setDueDate(today.minusDays(5));
        if (l2 != null) l2.setDueDate(today.minusDays(2));
        if (l3 != null) l3.setDueDate(today.plusDays(10));
        if (l4 != null) l4.setDueDate(today.minusDays(1));
        if (l5 != null) l5.setDueDate(today.plusDays(20));

		// ---- 5. create some reservations ----
    }

    /**
     * CSV format (simple): each line starts with a record type in column 0
     * BRANCH,id,name
     * BOOK,id,title,author,branchId
     * USER,id,name,email,username,password,role  (role: CUSTOMER|MANAGER|ADMIN)
     * BORROW,customerId,branchId,bookId,dueOffsetDays  (dueOffsetDays relative to today, can be negative)
     * RESERVE,customerId,branchId,bookId
     */
    private void loadFromCsv(LibrarySystem system, File csv) throws IOException {
        BranchCollection branches = system.getBranches();
        try (BufferedReader r = new BufferedReader(new FileReader(csv))) {
            String line;
            LocalDate today = LocalDate.now();
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                String[] parts = line.split(",", -1);
                String type = parts[0].trim().toUpperCase();
                switch (type) {
                    case "BRANCH": {
                        // BRANCH,id,name
                        if (parts.length < 3) break;
                        String id = parts[1].trim();
                        String name = parts[2].trim();
                        branches.addBranch(id, name);
                        break;
                    }
                    case "BOOK": {
                        // BOOK,id,title,author,branchId
                        if (parts.length < 5) break;
                        String id = parts[1].trim();
                        String title = parts[2].trim();
                        String author = parts[3].trim();
                        String branchId = parts[4].trim();
                        Branch b = branches.getBranch(branchId);
                        if (b == null) {
                            b = branches.addBranch(branchId, branchId);
                        }
                        Book book = new Book(id, title, author, b);
                        b.addBook(book);
                        break;
                    }
                    case "USER": {
                        // USER,id,name,email,username,password,role
                        if (parts.length < 7) break;
                        String id = parts[1].trim();
                        String name = parts[2].trim();
                        String email = parts[3].trim();
                        String username = parts[4].trim();
                        String password = parts[5].trim();
                        String role = parts[6].trim().toUpperCase();
                        User user = null;
                        switch (role) {
                            case "CUSTOMER":
                                user = new Customer(id, name, email, username, password);
                                break;
                            case "MANAGER":
                                user = new Manager(id, name, email, username, password);
                                break;
                            case "ADMIN":
                                user = new Admin(id, name, email, username, password);
                                break;
                            default:
                                // default to customer
                                user = new Customer(id, name, email, username, password);
                                break;
                        }
                        system.registerUser(user);
                        break;
                    }
                    case "BORROW": {
                        // BORROW,customerId,branchId,bookId,dueOffsetDays
                        if (parts.length < 4) break;
                        String customerId = parts[1].trim();
                        String branchId = parts[2].trim();
                        String bookId = parts[3].trim();
                        User u = system.getUserById(customerId);
                        if (!(u instanceof Customer)) {
                            // try to find by username
                            u = system.getUserById(customerId);
                        }
                        // Find customer by id or username
                        Customer c = null;
                        if (u instanceof Customer) c = (Customer) u;
                        else {
                            // try lookup by username map via login method (username,password unknown) - fallback: search usersById
                            Object userObj = null; // graceful fallback: iterate users - not exposed here; skip
                        }
                        if (c == null) break;
                        Loan loan = system.borrowBook(c, branchId, bookId);
                        if (loan != null && parts.length >= 5) {
                            String offsetStr = parts[4].trim();
                            try {
                                int offset = Integer.parseInt(offsetStr);
                                loan.setDueDate(today.plusDays(offset));
                            } catch (NumberFormatException nfe) {
                                // ignore
                            }
                        }
                        break;
                    }
                    case "RESERVE": {
                        // RESERVE,customerId,branchId,bookId
                        if (parts.length < 4) break;
                        String customerId = parts[1].trim();
                        String branchId = parts[2].trim();
                        String bookId = parts[3].trim();
                        User u = system.getUserById(customerId);
                        if (!(u instanceof Customer)) u = system.getUserById(customerId);
                        if (u instanceof Customer) {
                            Customer c = (Customer) u;
                            system.reserveBook(c, branchId, bookId);
                        }
                        break;
                    }
                    default:
                        // unknown type - skip
                        break;
                }
            }
        }
    }
}