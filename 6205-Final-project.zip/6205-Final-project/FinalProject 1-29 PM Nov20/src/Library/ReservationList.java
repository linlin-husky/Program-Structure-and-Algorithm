package Library;

import ADT.SBTHashMap;
import ADT.SBTArrayDeque;
import ADT.SBTArrayList; // store frozen customer
import Users.Customer;

/**
 * ReservationList
 * * Manage the dequeADT。
 * Combine the advantages of ArrayDeque and HashMap 
 */
public class ReservationList {


    private SBTArrayDeque<Customer> waitingQueue;

    private SBTHashMap<String, Boolean> statusMap; // string refers to CustomerID and Boolean is to track if the account is frozen or not.

    public ReservationList() {
        this.waitingQueue = new SBTArrayDeque<>();
        this.statusMap = new SBTHashMap<>();
    }


    /**
     * use hashmap method to check if the reservation is empty
     */
    public boolean isEmpty() {
        return statusMap.isEmpty();
    }

    /**
     * gain the real size of the hashmap;
     */
    public int size() {
        return statusMap.size();
    }

    /**
     * check if someone is in waiting list or not
     */
    public boolean contains(Customer customer) {
        if (customer == null) {
        	return false;
        }
        
        return statusMap.containsKey(customer.getId());
    }
    
    /**
     * check if one customer's status map is frozen or not
     */
    public boolean isFrozen(Customer customer) {
        if (customer == null) {
        	return false;
        }
        
        Boolean status = statusMap.get(customer.getId());

        return status != null && status; // ensure this person exists and the status shows the hold is frozen
    }



    /**
     * this is to use the array dequeue to track the normal waiting list queueing (FIFO)
     */
    public void add(Customer customer) {
        if (customer == null) return;
        String cid = customer.getId();

 
        // if the map has this ID, it shows it is already in line
        if (statusMap.containsKey(cid)) {
            return; 
        }

        // add this customer to the back like the normal waiting list
        waitingQueue.addToBack(customer);
        // the customer status is not frozen
        statusMap.put(cid, false);
    }

    /**
     * in case of emergency, add the customer to the top of queue.
     * this can only be done by the admin
     */
    public void addPriority(Customer customer) {
        if (customer == null) return;
        String cid = customer.getId();

        if (statusMap.containsKey(cid)) return;

        // put the customer to the front
        waitingQueue.addToFront(customer); 
        // record the status
        statusMap.put(cid, false);
    }


    /**
     * Freeze Hold
     * change the value in the Map to true。
     * after the customer freeze the hold, the customer can skip it with the previous position maintained
     */
    public void freezeHold(Customer customer) {
        if (customer != null && statusMap.containsKey(customer.getId())) {
            statusMap.put(customer.getId(), true); // true = Frozen
        }
    }

    /**unfreeze the hold. Change the value to false in the map
     */
    public void unfreezeHold(Customer customer) {
        if (customer != null && statusMap.containsKey(customer.getId())) {
            statusMap.put(customer.getId(), false); // false = Active
        }
    }

    /**
     * Cancel Hold and delete the customer from the statusMap, the efficiency is O(1)
     */
    public void remove(Customer customer) {
        if (customer != null) {
            statusMap.remove(customer.getId());
        }
    }

    /**
     * get the next person who eligible to get the book
     * There is no this person in this, discard it.
     * if this person status is frozen, reserve it into another 
     * if the status is false, then select this user and remove it from the map. 
     * put all frozen users into the start of the queue
     * * @return next active Customer. If there is no such one, then return null
     */
    	public Customer pollNext() {
            if (statusMap.isEmpty()) {
            	return null;
            }

            SBTArrayList<Customer> frozenSkipped = new SBTArrayList<>();
            Customer winner = null;

            while (!waitingQueue.isEmpty()) {
                Customer candidate = waitingQueue.removeFront();
                String cid = candidate.getId();
                Boolean isFrozen = statusMap.get(cid);

                if (isFrozen == null) {
                	continue; 
                }

                if (isFrozen) {
                    frozenSkipped.add(candidate); 
                } else {
                    winner = candidate; 
                    statusMap.remove(cid); 
                    break;
                }
            }

            for (int i = frozenSkipped.getLength(); i >= 1; i--) {
                 waitingQueue.addToFront(frozenSkipped.getEntry(i)); 
            }

            return winner;
        }
    	

   
        public SBTArrayList<String> getManagerReport() {

            SBTArrayList<String> reportList = new SBTArrayList<>();

            SBTArrayDeque<Customer> tempQueue = new SBTArrayDeque<>();

            int position = 1;

            while (!waitingQueue.isEmpty()) {
                Customer c = waitingQueue.removeFront(); 
                
                Boolean isFrozen = statusMap.get(c.getId());

          
                if (isFrozen == null) {
                	
                    continue; 
                }
 
                String statusStr = isFrozen ? "[Frozen/Skipped]" : "[Active]";
                String line = "Position " + position + ": " + c.getId() + " " + statusStr;
                reportList.add(line);
                
                tempQueue.addToBack(c);
                
                position++;
            }

            this.waitingQueue = tempQueue;

            return reportList;
        }
    	
}