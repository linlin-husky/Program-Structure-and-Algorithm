package Library;
import java.time.LocalDate;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.StringJoiner;
import java.util.StringTokenizer;

import ADT.SBTResizableBag;
import ADT.SBTBagADT;
import ADT.SBTArrayList;
import ADT.SBTHashMap;
import ADT.SBTHeapPriorityQueue;
import ADT.SBTListADT;
import ADT.SBTMapADT;
import ADT.SBTPriorityQueueADT;
import Users.Customer;
import Users.User;

	/**
	 * the handling system of the library
	 * manage the branch
	 * register users
	 * borrow, renew, reserve and return the book
	 * automatically check the due date and whether to renew the loan
	 */
	public class LibrarySystem {

       
		private final SBTMapADT<String, User> usersById;
		private final SBTMapADT<String, User> usersByUsername;
		private final SBTBagADT<Loan> allLoans; 
		private BranchCollection branches;
		private final SBTPriorityQueueADT<Loan> dueDatePQ;
		private static final int AUTO_RENEW_DAYS = 21; // automatic renewal days are 21 days.
		private static final int DEFAULT_LOAN_DAYS = 21;// when user borrow a book from library, due date is after 21 days 
		private ADT.SBTArrayList<Book> allBooks;

		public LibrarySystem() {
		this.branches = new BranchCollection();
		this.usersById = new SBTHashMap<>();
		this.usersByUsername = new SBTHashMap<>();
		this.allLoans = new SBTResizableBag<>();
		this.dueDatePQ = new SBTHeapPriorityQueue<>();
		this.allBooks = new SBTArrayList<Book>();
	}

  
	    
	    // for admin to register user
	    public void registerUser(User user) {
	        if (user == null) return;
	        usersById.put(user.getId(), user);
	        usersByUsername.put(user.getUsername(), user);
	    }

	    /**
	     * simple login test to check the roll Admin/Manager/Customer
	     */
	    public User login(String username, String password) {
	        User u = usersByUsername.get(username);
	        
	        if (u != null && u.getPassword().equals(password)) {
	        	
	            return u;
	        }
	        
	        return null;
	    }


	    /**
	     * borrow book 
	     * If the book is on shelf and hence available, we create a loan with default 21 days to track the borrowing. 
	     */
	    public Loan borrowBook(Customer customer, String branchId, String bookId) {
	        if (customer == null || branchId == null || bookId == null) {
	        	return null;
	        
	        	}

	        Branch branch = branches.getBranch(branchId);
	        if (branch == null) return null;

	        Book book = branch.findBook(bookId);
	        if (book == null) return null;


	        // create a loan to store book and customer information with default 21 days.
	        Loan loan = new Loan(book, customer, DEFAULT_LOAN_DAYS);
	        book.setAvailable(false);
	        loan.setStatus(Loan.Status.BORROWED);
	        book.cancelHold(customer);

	        allLoans.add(loan);
	        dueDatePQ.add(loan);
	        customer.addLoan(loan); 
	        return loan;
	    }
	    
	    /**
	     * Reservation book happens when the book you want is not available. You have to wait for your turn
	     * it is same to place an hold on this books. Once you are the first on the waiting list, you can borrow this book.
	     */
	    public Loan reserveBook(Customer customer, String branchId, String bookId) {
	        if (customer == null || branchId == null || bookId == null) 
	        	{
	        	return null;
	        	}
	        Branch branch = branches.getBranch(branchId);
	        
	        if (branch == null) {
	        	return null;
	        }

	        Book book = branch.findBook(bookId);
	        
	        if (book == null)  {
	        	return null;
	        }
	        book.addToWaitingList(customer);
            return null;

	          
	    }
	    
	    /**
	     * Handles the renewal logic.
	     * @return "SUCCESS", "RESERVED" (failed), "LIMIT" (failed), or "ERROR"
	     */
	    public String renewLoan(Loan loan) {
	        if (loan == null) {
	        	return "ERROR";
	        }

	        Book book = loan.getBook();

	        // Check if anyone is waiting for this book
	        if (book.hasWaitingCustomer()) {
	            return "RESERVED";
	        }

	        // Check if they hit the max renewal limit (e.g. 2 times)
	        if (!loan.canAutoRenew()) {
	            return "LIMIT";
	        }

	        // Process the renewal
	        loan.extendDueDate(DEFAULT_LOAN_DAYS);
	        loan.setStatus(Loan.Status.RENEWED);
	        
	        return "SUCCESS";
	    }

	    /**
	     * return logic: find the related loan and change the loan status to returned
	     * the book is available again. If there is someone on the waiting list, the book will be automatically
	     * passed to the next person with default 21 borrowing duration
	     */
	    public void returnBook(Customer customer, String branchId, String bookId) {
	        if (customer == null || branchId == null || bookId == null) // fail safe coding
	        {
               return;
	        }
	        
	        Branch branch = branches.getBranch(branchId);
	        
	        if (branch == null) 
        	{
        	   return;
        	}

	        Book book = branch.findBook(bookId);
	        if (book == null) return;

	        // set the related target as null first
	        Loan target = null;

	        // use array bag toArray method to iterate to find the customer
	        Object[] arr = allLoans.toArray();
	        
	        for (Object obj : arr) {
	            if (!(obj instanceof Loan)) { 
	            	continue;
	            }
	            
	            Loan loan = (Loan) obj;

	            if (loan.getBorrower().equals(customer) && loan.getBook().equals(book) & (loan.getStatus() == Loan.Status.BORROWED || loan.getStatus() == Loan.Status.RENEWED)) {
	                target = loan;
	                break;
	            }
	        }

	        if (target == null) // fail safe code for prevent null value to go into the next steps
	        {
	            return;
	        }
	        
	        target.setStatus(Loan.Status.RETURNED); // change status to returned 
//	        customer.removeLoan(target);// remove loan from customer records.
	        

	        //  check someone on the top of the book waiting list
	        Customer next = book.pollNextWaitingCustomer();
	        
	        if (next != null) { // check if this book has waiting list
	            // directly borrow this book to this customer and create a loan for this borrowing
	            Loan newLoan = new Loan(book, next, DEFAULT_LOAN_DAYS);
	            book.setAvailable(false); // flowing into the next reader the book is still unavailable
	            allLoans.add(newLoan);
	            dueDatePQ.add(newLoan);
	            next.addLoan(newLoan); 
	            next.removeFromWishList(book); 
	            
	        } else {
	            book.setAvailable(true);// no one in waiting list, the book becomes available
	        }
	    }
	    
	    public ADT.SBTArrayList<String> generateAllQueuesReport() {
	    	 ADT.SBTArrayList<String> result = new ADT.SBTArrayList<>();

			// start recursion at index 1 (the list is 1-based in this ADT)
			generateAllQueuesReportRecursive(1, result);
			return result;
	    }

	    // Recursive helper to iterate over allBooks
	    private void generateAllQueuesReportRecursive(int idx, ADT.SBTArrayList<String> result) {
			if (idx > allBooks.getLength()) {
				return;
			}

			Book currentBook = allBooks.getEntry(idx);
			if (currentBook != null && currentBook.hasWaitingCustomer()) {
				result.add("");
				result.add("title: " + currentBook.getTitle());
				result.add("ID: " + currentBook.getId());

				ADT.SBTArrayList<String> report = currentBook.getWaitListReport();
				// append each entry of the book's waitlist report recursively
				appendReportRecursive(report, 1, result);
			}

			// recurse to next book
			generateAllQueuesReportRecursive(idx + 1, result);
		}

		// Recursive helper to append a waitlist report (1-based ADT)
		private void appendReportRecursive(ADT.SBTArrayList<String> report, int idx, ADT.SBTArrayList<String> result) {
			if (report == null || idx > report.getLength()) {
				return;
			}
			result.add("  " + report.getEntry(idx));
			appendReportRecursive(report, idx + 1, result);
		}


	    /**
	     * means “process all loans due today through 7 days from now”. 
	     * Because the heap returns loans from earliest to latest,
	     *  the method processes those upcoming loans in chronological order.	    
	     *
	     */
	    public AutoRenewResult checkDueAndAutoRenew(LocalDate today, int daysAhead) {
	        AutoRenewResult result = new AutoRenewResult();

	        if (dueDatePQ.isEmpty()) {     	
	        		return result;
	        }

	        SBTPriorityQueueADT<Loan> tempPQ = new SBTHeapPriorityQueue<>();
	        LocalDate endDate = today.plusDays(daysAhead);

	        while (!dueDatePQ.isEmpty()) {	        	
	        	Loan nextLoan = dueDatePQ.peek();
	            LocalDate due = nextLoan.getDueDate();
	            
	            if (due == null) {
	                tempPQ.add(dueDatePQ.remove());
	                continue;
	            }

	            if (due.isAfter(endDate)) {
	                break;
	            }
                 
	            Loan loan = dueDatePQ.remove();
	            
	            if (loan.getStatus() == Loan.Status.BORROWED ||
	                loan.getStatus() == Loan.Status.RENEWED) {
	            	processSingleLoan(loan, result);
	            }
	            tempPQ.add(loan);
	        }

	        while (!tempPQ.isEmpty()) {
	            dueDatePQ.add(tempPQ.remove());
	        }

	        return result;
	    }
	    
	    //  If no one is reserving and reservation count is within 2 times, it can be automatically renewed
	    // or else it cannot be renewed.
	    private void processSingleLoan(Loan loan, AutoRenewResult result) {
	        Book book = loan.getBook();

	        // Rule 1: Waiting list exists -> No Renew
	        if (book.hasWaitingCustomer()) {
	            loan.setStatus(Loan.Status.DUE_SOON);
	        } 
	        // Rule 2: Over renew limit -> No Renew
	        else if (!loan.canAutoRenew()) {
	            loan.setStatus(Loan.Status.DUE_SOON);
	            result.getOverLimitLoans().add(loan);
	        } 
	        // Rule 3: Auto Renew
	        else {
	            loan.extendDueDate(AUTO_RENEW_DAYS);
	            loan.setStatus(Loan.Status.RENEWED);
	            result.getRenewedLoans().add(loan);
	        }
	    }
	    
//	    private void sendEmail(Customer customer, String message) {
//	        System.out.println("[Email] To " + customer.getEmail() + ": " + message);
//	    }
	    
	    public SBTListADT<Loan> getAllLoans() {
	        SBTListADT<Loan> list = new SBTArrayList<>();
	        Object[] arr = allLoans.toArray();
	        for (Object obj : arr) {
	            if (obj instanceof Loan) {
	                Loan loan = (Loan) obj;
	                list.add(loan);
	            }
	        }
	        return list;
	    }
	    
	    
	    /** all loans are put in a resizable array bag. we turn it to array to iterate
	     * @return a array list implementing list via array data structure for UI display
	     */
	    public Loan[] getCustomerLoans(Customer customer) {
	        
	        if (customer == null) {
	        	return new Loan[0];
	        }
	        
	        Object[] arr = allLoans.toArray();//use toArray() method is resizableArrayBag to change it to array.
	        Loan[] transArr = new Loan[arr.length];
	        int count = 0;
	        
	        for (Object obj : arr) {
	            Loan loan = (Loan) obj;
	          
		        if (customer.equals(loan.getBorrower()) && (loan.getStatus() == Loan.Status.BORROWED || loan.getStatus() == Loan.Status.RENEWED)) {
		        	transArr[count++] = loan;
	            }
	        }
	         
	        Loan[] result  = new Loan[count];
	        System.arraycopy(transArr, 0, result, 0, count);
	        return result;
	    }
	    
	    public User getUserById(String id) {
	        if (id == null) return null;
	        return usersById.get(id);
	    }

       public Branch addBranch(String id, String name) {
	        return branches.addBranch(id, name);
	    }

	    public Branch getBranch(String id) {
	        return branches.getBranch(id);
	    }

		public BranchCollection getBranches() {
			return branches;
		}
	    public SBTListADT<Branch> getAllBranches() {
	        return branches.getAllBranches();
	    }	   
	    public ADT.SBTArrayList<Book> getAllBooks() {
	        return this.allBooks;
	    }
}
