package Library;

import java.time.LocalDate;

import Users.Customer;


public class Loan implements Comparable<Loan> {
	
	    private static long currentId = 1;
	    private final String id;
	    private final Book book;
	    private final Customer borrower;
	    private LocalDate checkoutDate;
	    private LocalDate dueDate;
	    private int renewCount;
	    private static final int MAX_RENEW = 2;   // one customer can only renew twice at most

	    private Status status;
	
    public enum Status {
        BORROWED,     // checked out book, borrowed means the book was borrowed within the first 21 days.
        RETURNED,     // already returned
        DUE_SOON,     //  due soon
        RENEWED       // already renewed
    }



    public Loan(Book book, Customer borrower, int durationDays) {
        this.id = generateId();
        this.book = book;
        this.borrower = borrower;
        this.checkoutDate = LocalDate.now();
        this.dueDate = checkoutDate.plusDays(durationDays);
        this.renewCount = 0;
        this.status = Status.BORROWED;
    }

    private static String generateId() {
        return "LN" + (currentId++);
    }

    // renew logic

    public boolean canAutoRenew() {
        return renewCount < MAX_RENEW;
    }
    
    public boolean canRenew() {
        return canAutoRenew();
    }

    /**
     * extend renewal date if no one is on waiting list, and update renewCount
     */
    public void extendDueDate(int days) {
        if (dueDate != null) {
            dueDate = dueDate.plusDays(days);
            renewCount++;
        }
    }

    /**
     * compareTo set ups the order where the loan in earlier date will be more in front in the queue since its return
     * value is smaller. We add this compareTo to loan, which is similar to adding one attribute to this to keep the single truth 
     * of source. This ensured, in library system, when we create heap priority queue to manage the loan based on due date with the
     * smallest one on top, which is similar to the loan which is due most soon.
     */
    @Override
    public int compareTo(Loan other) {
        if (this.dueDate == null && other.dueDate == null) {
        	return 0;
        }
        
        if (this.dueDate == null) {
        	return 1;
        }
        
        if (other.dueDate == null) {
        	return -1;
        }
        
        return this.dueDate.compareTo(other.dueDate);
    }

 
    public String getId() {
        return id;
    }

    public Book getBook() {
        return book;
    }

    public Customer getBorrower() {
        return borrower;
    }

    public LocalDate getCheckoutDate() {
        return checkoutDate;
    }

    public void setCheckoutDate(LocalDate checkoutDate) {
        this.checkoutDate = checkoutDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public int getRenewCount() {
        return renewCount;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
    
}
