package Library;



import Users.Customer;

public class Book {
	private final String id;      // id is unique to book
    private String title;
    private String author;
    private boolean available;
    private Branch branch;
    
    // UPDATED: Replaced simple queue with your robust ReservationList ADT
    private ReservationList reservationList; 

    public Book(String id,
                String title,
                String author,
                Branch branch) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.branch = branch;
        this.available = true;
        
        // Initialize the new list
        this.reservationList = new ReservationList();
    }

 

    public boolean hasWaitingCustomer() {
        return !reservationList.isEmpty();
    }

    /**
     * Standard Add (FIFO)
     */
    public void addToWaitingList(Customer customer) {
        reservationList.add(customer);
    }
    
    /**
     * Priority Add (LIFO / VIP / System Restore)
     */
    public void addEmergencyHold(Customer customer) {
        reservationList.addPriority(customer);
    }

    /**
     * Get the next valid winner for the book.
     * Logic: Skips frozen users, cleans up cancelled users.
     */
    public Customer pollNextWaitingCustomer() {
        return reservationList.pollNext();
    }

    /**
     * Cancel a specific hold.
     * Efficiency: O(1) - Lazy deletion via HashMap
     */
    public void cancelHold(Customer target) {
        reservationList.remove(target);
    }

    /**
     * Check if user is already waiting.
     * Efficiency: O(1) - HashMap lookup
     */
    public boolean isOnWaitingList(Customer target) {
        return reservationList.contains(target);
    }
    
    public int getWaitingListSize() {
        return reservationList.size();
    }

    public void freezeHold(Customer target) {
        reservationList.freezeHold(target);
    }

    public void unfreezeHold(Customer target) {
        reservationList.unfreezeHold(target);
    }
    
    /**
     * Useful for UI to display "Status: Frozen" vs "Status: On Waitlist"
     */
    public boolean isHoldFrozen(Customer target) {
        return reservationList.isFrozen(target);
    }

  

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
    
    public Branch getBranch() {
        return branch;
    }

    public void setBranch(Branch branch) {
        this.branch = branch;
    }
    
    public ADT.SBTArrayList<String> getWaitListReport() {
        return reservationList.getManagerReport();
    }
}


