package Library;

import ADT.SBTArrayList;
import ADT.SBTListADT;

public class AutoRenewResult {
	
	        private final SBTListADT<Loan> renewedLoans = new SBTArrayList<>();
	        private final SBTListADT<Loan> overLimitLoans = new SBTArrayList<>();

	        public SBTListADT<Loan> getRenewedLoans() {
	            return renewedLoans;
	        }

	        public SBTListADT<Loan> getOverLimitLoans() {
	            return overLimitLoans;
	        }

	        public boolean hasAnyRenewed() {
	            return !renewedLoans.isEmpty();
	        }
	    }


